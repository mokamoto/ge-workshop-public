# 既存 SAST のベースライン

Lab 1 で CodeMender の結果と突き合わせるための、従来型静的解析ツールの実行結果。

## 収録ファイル

| ファイル | 中身 | 使いどころ |
|---|---|---|
| `bandit.json` | bandit 1.9.4 の生出力 | Lab 1 の比較 |
| `bandit-findings.json` | 上を CodeMender の Simple JSON に変換したもの | Lab 4 の `cm report import` |
| `semgrep.sarif` | **Semgrep OSS 1.172.0**（p/python + p/security-audit + p/owasp-top-ten + p/flask、694 ルールをロード）の SARIF 出力 | Lab 4 の SARIF インポート |

再生成する場合は `scripts/05_run_baseline_sast.sh` を実行する。

## 実測結果（2026-08-07 時点）

### 仕込んだ欠陥に対する検出状況

| ID | 欠陥 | 場所 | bandit | semgrep | 悪用可能か |
|---|---|---|---|---|---|
| V1 | SQL インジェクション | `app/reports.py:86` | ⚠️ 検出（MEDIUM / **確信度 LOW**） | ❌ 未検出 | **可能**（他テナントのレポートを窃取） |
| V2 | テナント越境 IDOR | `app/attachments.py:30`（`WHERE id = ?` に tenant 条件が無い） | ❌ **未検出** | ❌ **未検出** | **可能**（他社の社外秘添付を窃取） |
| V3 | コマンドインジェクション（に見えるもの） | `app/exporter.py:62` | ⚠️ 検出（**HIGH / 確信度 HIGH**） | ⚠️ 検出 | **不可能**（偽陽性） |
| V4 | SSRF | `app/webhook.py:34` | ❌ 未検出 | ❌ 未検出 | 可能（メタデータサーバに到達） |

### bandit の全 8 件

```
app/common/db.py:11       [B108] MEDIUM/MEDIUM  Probable insecure usage of temp file/directory.
app/common/storage.py:19  [B108] MEDIUM/MEDIUM  Probable insecure usage of temp file/directory.
app/exporter.py:14        [B404] LOW/HIGH       Consider possible security implications of subprocess
app/exporter.py:62        [B602] HIGH/HIGH      subprocess call with shell=True identified   ← 偽陽性
app/reports.py:86         [B608] MEDIUM/LOW     Possible SQL injection vector                ← 本物
app/seed.py:22            [B105] LOW/MEDIUM     Possible hardcoded password: 'acme-alice-token'
app/seed.py:23            [B105] LOW/MEDIUM     Possible hardcoded password: 'globex-bob-token'
app/seed.py:24            [B105] LOW/MEDIUM     Possible hardcoded password: 'acme-carol-token'
```

### semgrep の全 1 件

```
app/exporter.py:62  python.lang.security.audit.subprocess-shell-true   ← 偽陽性
```

## この数字が語っていること

Lab 1 のディスカッションではこの 3 点を押さえる。

**1. 最も深刻な欠陥が、両ツールとも完全に見えていない。**
V2（テナント越境 IDOR）は他社の社外秘データが丸ごと漏れる欠陥だが、bandit も semgrep も 1 件も挙げていない。
理由は原理的なもので、`attachments.py` の SQL は**プレースホルダを使った完全に正しい構文**だからである。
危険なのは構文ではなく「WHERE 句に `tenant_id` が無い」という**アプリ固有の不変条件の違反**であり、
これを検出するには「このアプリはマルチテナントである」「隣の `list_attachments()` や
`reports.py` では正しく絞っている」という**文脈の理解**が要る。パターンマッチでは届かない層。

**2. 最高スコアの検出結果が偽陽性である。**
bandit で唯一 HIGH/HIGH（重大度・確信度ともに最高）が付いたのは `exporter.py:62` の
`shell=True` だが、これは悪用できない。`storage.resolve_export_path()` が返すパスは
サーバ生成 UUID と許可リスト済み拡張子のみで構成され、シェルメタ文字が構造上入り込めないため。
semgrep に至っては、検出した 1 件がこれだけである。
**トリアージ担当者は、最優先で対応すべきと表示された項目に時間を使い、本当の穴には気づかない。**

**3. 本物の SQL インジェクションは確信度 LOW に埋もれている。**
V1 は実際に他テナントのデータを取り出せる本物の欠陥だが、bandit の確信度は LOW。
ノイズ 5 件（`/tmp` の使用 2 件、subprocess の import、デモ用トークンを「ハードコードされた
パスワード」と誤認 3 件）と同じ画面に並ぶ。

> 8 件のうち、本物は 1 件。最高スコアは偽陽性。最も危険な欠陥は 0 件検出。
> これが「アラート疲れ」の実態であり、Lab 2 の `cm verify` が解こうとしている問題である。

## この比較は公平か — 想定される反論と答え

**鋭い受講者は必ずここを突いてくる。** 答えを用意しておかないと、
比較そのものが「都合よく作った藁人形」に見えてしまう。

### 反論1「Semgrep Pro なら見つかるのでは？」

**使ったのは Semgrep OSS 1.172.0（694 ルール）である。Pro は未検証。**
これは正直に認めるべき。Pro には interfile（ファイル横断）の taint 解析がある。

ただし **V2 は taint の問題ではない。** ユーザー入力が危険な場所に到達する話ではなく、
「WHERE 句に条件が**足りない**」という**不在**の問題である。
データフローを追う能力を強化しても、原理的に届きにくい種類の欠陥である。

とはいえ**顧客が Pro を使っているなら、その場で回して確かめるのが誠実**である。
「OSS では出ませんでした。御社の Pro でも試してみましょう」と言えるようにしておく。

### 反論2「カスタムルールを書けば検出できるのでは？」

**そのとおり、書ける。** 「attachments テーブルへのクエリには `tenant_id` 条件を必須とする」
というルールは semgrep で表現できる。ここは譲ってよい。

**論点は「書けるかどうか」ではなく「誰がその不変条件に気づくか」である。**

- カスタムルールを書くには、**人間が先にその不変条件を知っていて、明文化して、
  ルールとして書いて、保守し続けている**必要がある
- CodeMender は**それをコードベースから推論した**。
  「`list_attachments()` と `get_report()` は tenant で絞っているのに、
  `download_attachment()` だけ絞っていない」という形で

つまり比較しているのは検出能力そのものではなく、
**「不変条件を人間が事前に言語化する必要があるか」** である。
新しい規約が生まれるたびにルールを書き足す運用と、コードから読み取る運用の差。

### 反論3「bandit のノイズはツールの使い方が悪いだけでは？」

これも一理ある。`B108`（`/tmp` の使用）や `B105`（デモ用トークンを
「ハードコードされたパスワード」と誤認）は、設定を詰めれば抑制できる。

ただし**抑制するには「これはノイズだ」と人間が判断する工程が必要**で、
その工程こそが工数である。「8 件中の本物 1 件」という比率は、
チューニング前の素の状態を示している点は明示すること。

> **総じて言えること**
> 「既存 SAST は無能だ」ではない。**「既存 SAST は、人間が知っていることしか
> 探せない」**である。この言い方なら誇張がなく、実測とも整合する。

## 注意

`cm find` は LLM エージェントによる検査なので、実行ごとに結果が変わりうる。
一方この表の bandit / semgrep の数字は決定的で、何度実行しても同じになる
（実際、2026-09-02 に bandit を再実行して 8 件が完全一致することを確認済み。
8 件目は `app/comments.py` 追加時に増えたテスト用トークン `TOKEN_CAROL` への B105 で、
この件数はコードを変えない限り動かない）。
講義では「変わらない側」を先に見せてから CodeMender を走らせると対比が効く。
