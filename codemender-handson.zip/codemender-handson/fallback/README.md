# 非決定性の保険（fallback）

## これは何か

`cm find` は LLM エージェントによる検査なので、**実行するたびに結果が変わりうる**。
Step 2 のスキャンが Step 3 以降で使う予定の finding を挙げてこないことは普通に起こる。

`findings.json` は、そうなった受講者が**ラボを止めずに合流するため**の
事前定義済み findings である。CodeMender が正式にサポートする
Simple JSON 形式（`file_path` / `line` / `title` / `message` / `severity` / `vuln_type`）で
記述してある。

## 使い方

```bash
cm report import -f fallback/findings.json
cm report                       # 採番された finding ID を確認
cm verify <FINDING_ID>          # ここから通常どおり Step 3 へ
```

インポートした finding は `cm find` が生成したものと同様に扱われ、
`cm verify` / `cm fix` にそのまま流せる。

## 収録している finding

| ID | ファイル | 種別 | 想定される verify 結果 |
|---|---|---|---|
| V2 | `app/attachments.py:30` | CWE-639 テナント越境 IDOR | **VERIFIED** |
| V1 | `app/reports.py:87` | CWE-89 SQL インジェクション | **VERIFIED** |
| V4 | `app/webhook.py:34` | CWE-918 SSRF | **VERIFIED** |
| V3 | `app/exporter.py:62` | CWE-78 コマンドインジェクション | **DISMISSED**（偽陽性） |
| V5 | `native/csvparse.c:62` | CWE-787 ヒープバッファオーバーフロー | **VERIFIED** |

## 講師向けの注意

- V3 の `message` は**わざと中立的な書き方**にしてある。「これは偽陽性です」と
  書いてしまうと、`cm verify` にヒントを与えてしまい、Step 3 の山場が成立しない。
- 「想定される verify 結果」はあくまで想定であり、保証ではない。
  異なる結果になった場合はそれ自体を教材にする（`TUTORIAL.md` の「困ったときは」を参照）。
- 行番号は `app/` を修正すると当然ずれる。`cm vcs reset` でクリーンな状態に
  戻してから import すること。
