#!/usr/bin/env bash
#
# CodeMender プレビュー アクセス診断
#
# 「許可を受けたはずなのに動かない」ときに、原因の切り分けと
# 申請窓口へ提出する証跡の収集を一度に行う。
#
#   ./scripts/98_diagnose_access.sh
#
# 出力をそのまま Google Cloud の担当営業 / サポートに送れる形にしてある。
# 機微情報（アクセストークン、refresh token）は出力しない。
set -uo pipefail   # 診断目的なので -e は付けない（失敗しても続行して全項目を見る）

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"

ok()   { printf "  \033[32m✓\033[0m %s\n" "$*"; }
ng()   { printf "  \033[31m✗\033[0m %s\n" "$*"; }
warn() { printf "  \033[33m!\033[0m %s\n" "$*"; }

echo "===================================================================="
echo "  CodeMender プレビュー アクセス診断"
echo "  収集日時: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
echo "===================================================================="

# --- 1. クライアント ---------------------------------------------------
echo
echo "--- 1. CLI ---------------------------------------------------------"
if command -v cm >/dev/null 2>&1; then
  ok "cm: $(command -v cm) / $(cm --version 2>/dev/null)"
  latest="$(gcloud artifacts versions list \
      --project=cmoc-prod --location=us \
      --repository=codemender-cli-production --package=cm \
      --format='value(name)' 2>/dev/null | grep -E '^[0-9]' | sort -V | tail -1)"
  [[ -n "${latest}" ]] && echo "     公開されている最新バージョン: ${latest}"
else
  ng "cm が見つかりません"
fi

# --- 2. 認証 -----------------------------------------------------------
echo
echo "--- 2. 認証 --------------------------------------------------------"
ACCOUNT="$(gcloud config get-value account 2>/dev/null)"
echo "     gcloud アクティブアカウント : ${ACCOUNT}"

ADC_PATH="${HOME}/.config/gcloud/application_default_credentials.json"
# Cloud Shell では ADC ファイルが無いまま ADC が使える（メタデータサーバ経由）。
# ファイルの有無ではなく、実際にトークンが取れるかで判定する。
if gcloud auth application-default print-access-token >/dev/null 2>&1; then
  ok "ADC トークン取得成功（スコープ: cloud-platform）"
else
  ng "ADC トークンが取得できません → gcloud auth application-default login"
fi
if [[ -f "${ADC_PATH}" ]]; then
  ok "ADC ファイルあり"
  python3 - "${ADC_PATH}" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
print(f"     ADC type              : {d.get('type')}")
print(f"     ADC quota_project_id  : {d.get('quota_project_id')}   <-- CodeMender はこれを見る")
PY
else
  warn "ADC ファイルなし（Cloud Shell 等の環境提供クレデンシャルの場合は正常）"
  echo "     → その場合は export GOOGLE_CLOUD_PROJECT=<PROJECT_ID> を必ず設定すること"
fi

# --- 3. プロジェクト ---------------------------------------------------
echo
echo "--- 3. プロジェクト ------------------------------------------------"
PROJECT_ID="${GOOGLE_CLOUD_PROJECT:-$(gcloud config get-value project 2>/dev/null)}"
echo "     対象プロジェクト            : ${PROJECT_ID}"
echo "     GOOGLE_CLOUD_PROJECT        : ${GOOGLE_CLOUD_PROJECT:-<未設定>}"
PROJECT_NUMBER="$(gcloud projects describe "${PROJECT_ID}" --format='value(projectNumber)' 2>/dev/null)"
echo "     プロジェクト番号            : ${PROJECT_NUMBER:-<取得失敗>}"

# --- 4. API ------------------------------------------------------------
echo
echo "--- 4. 必要な API --------------------------------------------------"
enabled="$(gcloud services list --enabled --project="${PROJECT_ID}" --format='value(config.name)' 2>/dev/null)"
if [[ -z "${enabled}" ]]; then
  # 照会そのものの失敗と「無効」を混同しない。
  # gcloud のメタデータ照会が失敗しても cm 本体は動くことがある（実測あり）。
  warn "API 一覧を照会できませんでした（無効とは限りません）"
  warn "  → 手動確認: gcloud services list --enabled --project=${PROJECT_ID}"
else
  for api in aiplatform.googleapis.com cloudresourcemanager.googleapis.com; do
    if printf '%s\n' "${enabled}" | grep -qx "${api}"; then ok "${api}"; else ng "${api} が無効"; fi
  done
fi

# --- 5. IAM ------------------------------------------------------------
echo
echo "--- 5. IAM ---------------------------------------------------------"
roles="$(gcloud projects get-iam-policy "${PROJECT_ID}" \
    --flatten='bindings[].members' \
    --filter="bindings.members:${ACCOUNT}" \
    --format='value(bindings.role)' 2>/dev/null | sort -u)"
if [[ -n "${roles}" ]]; then
  if printf '%s\n' "${roles}" | grep -qE 'roles/(aiplatform.user|aiplatform.admin|owner|editor)'; then
    ok "aiplatform を使えるロールあり"
  else
    warn "roles/aiplatform.user が見当たりません"
  fi
  printf '%s\n' "${roles}" | sed 's/^/       /'
else
  warn "IAM ポリシーを取得できませんでした（権限不足の可能性）"
fi

# --- 6. 実接続テスト ---------------------------------------------------
echo
echo "--- 6. StartSession 実接続テスト -----------------------------------"
echo "     ここが本命。上の 1〜5 が失敗していても、これが OK なら利用可能。"
probe_dir="$(mktemp -d)"
trap 'rm -rf "${probe_dir}"' EXIT
cat > "${probe_dir}/probe.py" <<'PY'
import sqlite3
def lookup(conn, user_id):
    # 診断用の最小サンプル
    return conn.execute(f"SELECT * FROM users WHERE id = '{user_id}'").fetchone()
PY

raw="$(cm find "${probe_dir}/probe.py" -y --verbose < /dev/null 2>&1)"
api_error="$(printf '%s\n' "${raw}" | grep -o 'StartSession API error:.*' | head -1)"

if printf '%s\n' "${raw}" | grep -q "Unsupported agent interaction: codemender-preview"; then
  ng "許可リスト未登録"
  echo
  echo "     サーバ応答:"
  echo "       ${api_error}"
  echo
  echo "     意味: 認証は成立しているが、この呼び出し元に対して"
  echo "           codemender-preview というエージェント種別が有効化されていない。"
  RESULT="NOT_ALLOWLISTED"
elif printf '%s\n' "${raw}" | grep -qi "setup has just started"; then
  warn "バックエンドのリソース準備中（初回のみ）。1〜2 分待って再実行してください。"
  RESULT="PROVISIONING"
elif printf '%s\n' "${raw}" | grep -qE "Found [0-9]+ vulnerabilit|No vulnerabilities|Completed [0-9]+ tool step"; then
  ok "StartSession 成功。CodeMender は利用可能です。"
  printf '%s\n' "${raw}" | grep -E "Completed [0-9]+ tool step|Found [0-9]+ vulnerabilit" | sed 's/^/       /'
  RESULT="OK"
else
  warn "判定不能。生ログの末尾:"
  printf '%s\n' "${raw}" | tail -12 | sed 's/^/       /'
  RESULT="UNKNOWN"
fi

# --- 7. まとめ ---------------------------------------------------------
echo
echo "===================================================================="
echo "  判定: ${RESULT}"
echo "===================================================================="

if [[ "${RESULT}" == "NOT_ALLOWLISTED" ]]; then
cat <<EOF

以下をそのまま Google Cloud の担当営業／サポートにお送りください。
──────────────────────────────────────────────────────────────
CodeMender プレビューのアクセスが有効になっていないようです。
確認をお願いいたします。

  プロジェクト ID     : ${PROJECT_ID}
  プロジェクト番号     : ${PROJECT_NUMBER:-unknown}
  リクエスト元アカウント : ${ACCOUNT}
  ADC quota project   : $(python3 -c "import json;print(json.load(open('${ADC_PATH}')).get('quota_project_id'))" 2>/dev/null || echo unknown)
  CLI バージョン       : $(cm --version 2>/dev/null)
  発生日時 (UTC)      : $(date -u '+%Y-%m-%dT%H:%M:%SZ')

  エンドポイント       : https://aiplatform.googleapis.com
  サーバ応答           :
    HTTP 403
    {"error":{"message":"Unsupported agent interaction: codemender-preview",
              "code":"permission_denied"}}

  確認済み（クライアント側の問題ではないこと）:
    - aiplatform.googleapis.com / cloudresourcemanager.googleapis.com 有効
    - ADC のトークン取得可能（cloud-platform スコープ）
    - CLI は公開されている最新バージョン
    - --model / GOOGLE_CLOUD_PROJECT を明示しても同じ応答
──────────────────────────────────────────────────────────────

なお、許可が「別のプロジェクト」または「別のアカウント」に対して
付与されている可能性もあります。次も併せてご確認ください。

  1. 申請したプロジェクト ID が ${PROJECT_ID} と一致しているか
  2. 申請したアカウントが ${ACCOUNT} と一致しているか
     （異なる場合: gcloud auth application-default login --account=<申請したアカウント>）
  3. ADC の quota project が申請済みプロジェクトを指しているか
     （異なる場合: gcloud auth application-default set-quota-project <申請済みID>）
EOF
fi

echo
[[ "${RESULT}" == "OK" ]] && exit 0 || exit 1
