#!/usr/bin/env python3
"""Normalize `cm report --format json` findings across CLI versions.

cm 0.6.0 renamed every key in the JSON report from PascalCase to snake_case
(`FilePath` -> `file_path`, `Severity` -> `severity`, ...). Because the CI
workflows download `cm` by the floating `stable` label, that change arrived
silently: triage saw 12 findings with blank severity and selected none, and the
SARIF converter saw no file paths and uploaded an empty report -- all while the
checks stayed green.

Every script that reads a raw cm report goes through `normalize_findings()`,
which fills the PascalCase keys the code base uses from their snake_case twins.
PascalCase input is passed through unchanged, so pre-0.6.0 reports and the
existing fixtures keep working.
"""

from __future__ import annotations

import json

# PascalCase key used in this repo  ->  snake_case key emitted by cm >= 0.6.0
KEY_MAP: dict[str, str] = {
    "FindingID": "finding_id",
    "FilePath": "file_path",
    "StartLine": "start_line",
    "EndLine": "end_line",
    "Severity": "severity",
    "Status": "status",
    "Title": "title",
    "VulnType": "vuln_type",
    "Fingerprint": "fingerprint",
    "Confidence": "confidence",
    "Analysis": "analysis",
    "Snippet": "snippet",
    "SessionID": "session_id",
    "VulnID": "vuln_id",
}


def normalize_finding(finding: dict) -> dict:
    """Return a copy with PascalCase keys populated from snake_case where missing."""
    out = dict(finding)
    for pascal, snake in KEY_MAP.items():
        if pascal not in out and snake in out:
            out[pascal] = out[snake]
    return out


def normalize_findings(findings: list[dict]) -> list[dict]:
    return [normalize_finding(f) for f in findings if isinstance(f, dict)]


def load_findings(raw: str) -> list[dict]:
    """Parse cm report JSON (a list, or {"findings": [...]}) and normalize it."""
    if not raw.strip():
        return []
    data = json.loads(raw)
    if isinstance(data, dict):
        data = data.get("findings") or next(
            (v for v in data.values() if isinstance(v, list)), []
        )
    return normalize_findings(data)
