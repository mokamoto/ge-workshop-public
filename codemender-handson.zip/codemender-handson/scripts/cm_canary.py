#!/usr/bin/env python3
"""Fail loudly when a scan of this repository sees none of its seeded vulnerabilities.

This repo carries intentional vulnerabilities as teaching material (IDOR in
app/attachments.py, SQL injection in app/reports.py, SSRF in app/webhook.py). A
scan of app/ that reports none of them is not a clean result -- it is a broken
pipeline. That is exactly what happened for ten days after cm 0.6.0 changed its
report schema: every check stayed green while triage read blank findings.

Usage:
    python scripts/cm_canary.py --report /tmp/cm-nightly/report.json --out /tmp/cm-nightly/canary.json

Always exits 0 (advisory, never a gate). Emits a GitHub `::warning::` annotation
on a miss and writes {"canary_ok": bool, "matched": [...], "expected": [...]}.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from cm_findings import load_findings  # noqa: E402

# Seeded vulnerabilities the material depends on. Any one of them being reported
# is enough to prove the pipeline can see findings at all.
SEEDED_FILES: dict[str, str] = {
    "app/attachments.py": "IDOR (cross-tenant attachment download)",
    "app/reports.py": "SQL injection (report search)",
    "app/webhook.py": "SSRF (webhook registration)",
}


def check(findings: list[dict]) -> dict:
    """Which seeded files appear among the findings. Paths may be absolute or bare."""
    matched: set[str] = set()
    for f in findings:
        fp = str(f.get("FilePath") or "").replace("\\", "/")
        if not fp:
            continue
        for rel in SEEDED_FILES:
            if fp == rel or fp.endswith("/" + rel) or pathlib.Path(fp).name == pathlib.Path(rel).name:
                matched.add(rel)
    return {
        "canary_ok": bool(matched),
        "matched": sorted(matched),
        "expected": sorted(SEEDED_FILES),
        "findings_total": len(findings),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--report", required=True, help="cm report --format json")
    ap.add_argument("--out", required=True, help="where to write the JSON verdict")
    args = ap.parse_args()

    path = pathlib.Path(args.report)
    findings = load_findings(path.read_text(encoding="utf-8")) if path.exists() else []
    result = check(findings)
    pathlib.Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")

    if result["canary_ok"]:
        print(f"[cm_canary] OK: seeded vulnerabilities seen in {result['matched']}", file=sys.stderr)
    else:
        msg = (
            f"scan reported {result['findings_total']} finding(s) but none in the seeded files "
            f"{result['expected']}. The pipeline is probably broken (schema change, wrong scan "
            "target, auth), not the code clean."
        )
        print(f"::warning title=CodeMender canary missed::{msg}")
        print(f"[cm_canary] MISS: {msg}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
