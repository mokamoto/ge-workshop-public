#!/usr/bin/env bash
#
# CodeMender CLI (cm) を導入する。
#
# Cloud Shell では /usr/local/bin がセッション間で永続しないため、
# $HOME/bin に配置して PATH に追加する。
set -euo pipefail

INSTALL_DIR="${CM_INSTALL_DIR:-${HOME}/bin}"
# Pinned to the version the material was measured on. `stable` is a floating
# label that moved 0.5.0 -> 0.6.0 -> 0.7.0 within two weeks and changed the
# report format on the way; attendees must get the same cm the instructor
# rehearsed with. 0.11.0 is required for `cm find --deep`, which the tutorial
# uses. Override with CM_VERSION=... to test a newer build.
CM_VERSION="${CM_VERSION:-0.11.0}"

if command -v cm >/dev/null 2>&1; then
  installed="$(cm --version 2>/dev/null | awk '{print $NF}')"
  if [[ "${installed}" == "${CM_VERSION}" ]]; then
    echo "[01_install_cm] cm ${CM_VERSION} は導入済み: $(command -v cm)"
    exit 0
  fi
  # Measured (2026-09-14 rehearsal): this script used to stop at "already
  # installed", so an attendee who had pre-tested on an older cm silently kept
  # it. The material is validated on ${CM_VERSION} only, so replace other versions.
  echo "[01_install_cm] 別の版の cm (${installed:-unknown}) が入っています: $(command -v cm)"
  echo "[01_install_cm] 教材で検証済みの ${CM_VERSION} に入れ替えます。"
fi

# OS / アーキテクチャからアーティファクト名を決める。
os="$(uname -s)"
arch="$(uname -m)"
case "${os}/${arch}" in
  Linux/x86_64)   artifact="cm-linux-amd64.zip"  ;;
  Linux/aarch64)  artifact="cm-linux-arm64.zip"  ;;
  Darwin/x86_64)  artifact="cm-darwin-amd64.zip" ;;
  Darwin/arm64)   artifact="cm-darwin-arm64.zip" ;;
  *)
    echo "[01_install_cm] ERROR: 未対応の環境: ${os}/${arch}" >&2
    exit 1
    ;;
esac

echo "[01_install_cm] 環境: ${os}/${arch} -> ${artifact}"

tmp_dir="$(mktemp -d)"
trap 'rm -rf "${tmp_dir}"' EXIT

echo "[01_install_cm] Artifact Registry から取得しています..."
gcloud artifacts generic download \
  --project=cmoc-prod \
  --location=us \
  --repository=codemender-cli-production \
  --package=cm \
  --version="${CM_VERSION}" \
  --name="${artifact}" \
  --destination="${tmp_dir}"

unzip -o -q "${tmp_dir}/${artifact}" -d "${tmp_dir}"

mkdir -p "${INSTALL_DIR}"
install -m 0755 "${tmp_dir}/cm" "${INSTALL_DIR}/cm"
echo "[01_install_cm] 配置しました: ${INSTALL_DIR}/cm"

# PATH に無ければ .bashrc / .zshrc に追記する（冪等）。
if ! printf '%s' ":${PATH}:" | grep -q ":${INSTALL_DIR}:"; then
  for rc in "${HOME}/.bashrc" "${HOME}/.zshrc"; do
    [[ -f "${rc}" ]] || continue
    if ! grep -qF "# codemender-handson PATH" "${rc}"; then
      {
        echo ""
        echo "# codemender-handson PATH"
        echo "export PATH=\"${INSTALL_DIR}:\$PATH\""
      } >> "${rc}"
      echo "[01_install_cm] PATH を ${rc} に追記しました"
    fi
  done
  echo "[01_install_cm] 注意: 現在のシェルに反映するには次を実行してください"
  echo "                export PATH=\"${INSTALL_DIR}:\$PATH\""
fi

"${INSTALL_DIR}/cm" --version

# If an older cm elsewhere on PATH still shadows the pinned one, say so loudly.
resolved="$(command -v cm 2>/dev/null || true)"
if [[ -n "${resolved}" && "${resolved}" != "${INSTALL_DIR}/cm" ]]; then
  echo "[01_install_cm] ⚠️  PATH 上では ${resolved} が先に見つかります。"
  echo "[01_install_cm]    新しいシェルを開くか、その古い cm を外してください（教材は ${CM_VERSION} 前提）。"
fi
