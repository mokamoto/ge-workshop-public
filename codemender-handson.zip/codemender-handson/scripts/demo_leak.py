"""テナント越境で情報が漏れることを実演する（TUTORIAL 2-7）。

Acme 社の alice のログイン情報で、Globex 社の添付ファイルを要求する。
本来は他社のものなので見られてはいけない。

    uv run --no-sync python scripts/demo_leak.py
"""

import pathlib
import sys
import tempfile

# scripts/ から実行されるため、リポジトリのルートを import 対象に加える
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from app import seed
from app.common import db
from app.main import create_app


def main() -> None:
    tmp = pathlib.Path(tempfile.mkdtemp()) / "e.db"
    conn = db.connect(tmp)
    seed.seed(conn)
    conn.close()
    client = create_app(tmp).test_client()

    # Acme の alice のログイン情報で、Globex の添付ファイルを要求する
    res = client.get(
        f"/api/attachments/{seed.ATTACHMENT_GLOBEX}",
        headers={"Authorization": f"Bearer {seed.TOKEN_ALICE}"},
    )
    print("HTTP ステータス:", res.status_code)
    print("取得できた中身  :", res.get_json()["content"])


if __name__ == "__main__":
    main()
