#!/usr/bin/env python3
"""CodeMender の findings を GitHub Code Scanning が受け付ける SARIF に変換する。

    cm report --format json | uv run python scripts/cm_to_sarif.py > codemender.sarif

★なぜこのスクリプトが必要か★

`cm report --format sarif` は SARIF 2.1.0 を出力するが、実測（cm 0.2.0〜0.5.0）では
GitHub Code Scanning がそのまま受け付けられない形になっている。

  1. `region` が付かない  … 25 件中 0 件。GitHub は startLine を必須とする
  2. `artifactLocation.uri` が絶対ローカルパス
     … `/Users/you/repo/app/x.py` のような値。リポジトリ相対でないと
        アラートがファイルに紐付かない。加えてローカルの絶対パスが
        SARIF に残るのは情報漏洩でもある

行番号自体は `cm report --format json` の `StartLine` に入っている。
つまりデータはあるのに SARIF 側で落ちている。そこで JSON から組み立て直す。

将来 `cm report --format sarif` がこれらを満たすようになれば、このスクリプトは不要になる。
その場合は Lab 4 の手順を戻すこと。

★cm 0.6.0 で JSON のキーが snake_case に変わった★（`FilePath` → `file_path` 等）。
`cm_findings.normalize_findings` が両方を受けるので、ここでは PascalCase で読む。
入力があるのに 1 件も変換できなかったときは（スキーマ変更の再発を疑って）
空の SARIF を黙って出さず、終了コード 2 で止める。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from cm_findings import load_findings, normalize_findings  # noqa: E402

# CodeMender の severity → SARIF の level
LEVEL_BY_SEVERITY = {
    "CRITICAL": "error",
    "HIGH": "error",
    "MEDIUM": "warning",
    "LOW": "note",
}

# GitHub Code Scanning に載せない状態
SKIP_STATUSES = {"DISMISSED"}


def _index_by_basename(repo_root: Path) -> dict[str, list[str]]:
    """リポジトリ内のファイルを basename → 相対パス一覧 で索引する。"""
    index: dict[str, list[str]] = {}
    skip = {".git", ".venv", "node_modules", "__pycache__", "out", ".pytest_cache"}
    for dirpath, dirnames, filenames in os.walk(repo_root):
        dirnames[:] = [d for d in dirnames if d not in skip and not d.startswith(".")]
        for fn in filenames:
            rel = (Path(dirpath) / fn).relative_to(repo_root).as_posix()
            index.setdefault(fn, []).append(rel)
    return index


def to_repo_relative(file_path: str, repo_root: Path, basename_index: dict) -> str | None:
    """リポジトリ相対パスに正規化する。解決できなければ None。

    cm の FilePath は 3 通りの形で来る（実測）:
      1. 絶対パス   /Users/you/repo/app/x.py   → 相対化する
      2. 相対パス   app/x.py                    → そのまま
      3. ベース名のみ x.py                       → リポジトリ内を検索して解決
         （単一ファイルを対象にスキャンした場合にこの形になる）

    GitHub Code Scanning はリポジトリ内に実在するパスでないとアラートを
    紐付けられないため、解決できないものは呼び出し側で除外する。
    """
    # ★実測（run 33822854658 系）★ cm は FilePath が空の finding を返すことがある
    # （ファイルに紐付かない一般的な指摘など）。空文字を放置すると
    # `"".removeprefix("./")` が "" になり、`repo_root / ""` はリポジトリルート
    # （＝存在する）に一致してしまうため、uri="" の result を吐く。GitHub Code
    # Scanning はこれを "expected artifact location" で拒否し、SARIF 全体が落ちる。
    file_path = str(file_path or "").strip()
    if not file_path:
        return None

    p = Path(file_path)
    rel: str | None

    if p.is_absolute():
        try:
            rel = p.resolve().relative_to(repo_root.resolve()).as_posix()
        except ValueError:
            # ★実測★ 別マシン（CI ランナー等）で記録された絶対パスを、
            # 別の環境（ローカルの手元リポジトリ等）で読むとここに来る。
            # 即座に諦めず、下の basename フォールバックに委ねる。
            rel = None
    else:
        # removeprefix であって lstrip ではない。lstrip("./") は先頭の "." と "/" を
        # まとめて剥ぐので ".env.example" が "env.example" に化ける。
        rel = file_path.removeprefix("./")

    # `rel` truthy に加えて .is_file() を要求する。空文字やディレクトリを指す
    # finding を、実在するファイルのように扱って空/無効な uri を出さないため。
    if rel and (repo_root / rel).is_file():
        return rel

    # ベース名だけで来たケース、または上のどちらも解決できなかったケースを
    # 救済する。一意に定まるときのみ採用する。
    candidates = basename_index.get(Path(file_path).name, [])
    if len(candidates) == 1:
        return candidates[0]
    return None


def build_sarif(findings: list[dict], repo_root: Path, tool_version: str) -> dict:
    findings = normalize_findings(findings)
    rules: dict[str, dict] = {}
    results: list[dict] = []
    skipped_unresolved = 0
    considered = 0
    basename_index = _index_by_basename(repo_root)

    for f in findings:
        if str(f.get("Status", "")).upper() in SKIP_STATUSES:
            continue
        considered += 1

        uri = to_repo_relative(str(f.get("FilePath", "")), repo_root, basename_index)
        if uri is None:
            # リポジトリ内に解決できない finding は Code Scanning に載せられない
            skipped_unresolved += 1
            continue

        rule_id = str(f.get("VulnType") or f.get("Title") or "codemender")
        if rule_id not in rules:
            rules[rule_id] = {
                "id": rule_id,
                "name": rule_id.replace(" ", ""),
                "shortDescription": {"text": rule_id},
                "defaultConfiguration": {
                    "level": LEVEL_BY_SEVERITY.get(
                        str(f.get("Severity", "")).upper(), "warning"
                    )
                },
                "properties": {"tags": ["security", "codemender"]},
            }

        start_line = int(f.get("StartLine") or 1)
        end_line = int(f.get("EndLine") or start_line)
        if end_line < start_line:
            end_line = start_line

        # 同一 finding が再スキャンで重複しないよう安定した指紋を与える。
        # cm 側の Fingerprint があればそれを使う。
        #
        # ★実測（run 33359745081 系）★ 以前は指紋に Title を混ぜていた。Title は
        # LLM が実行のたびに言い換える（「SQL Injection in reports search endpoint」↔
        # 「SQL injection in search_reports」）ため、同じ脆弱性でも指紋が変わり、
        # GitHub 側で旧アラートが「解決」扱いで閉じて新アラートが開く churn を起こす。
        # 指紋は「ファイル × 脆弱性の種類」だけで決める。VulnType（CWE）は実行間で
        # 安定しているのでこれを使い、無ければ VulnType 欠落時の rule_id にフォール
        # バックする（Title は使わない）。行番号も実行ごとに数行揺れるため含めない。
        fingerprint = str(f.get("Fingerprint") or "").strip()
        if not fingerprint:
            stable_type = str(f.get("VulnType") or "").strip() or rule_id
            fingerprint = hashlib.sha256(
                f"{uri}:{stable_type}".encode("utf-8")
            ).hexdigest()[:32]

        message = str(f.get("Title") or "CodeMender finding")
        analysis = str(f.get("Analysis") or "").strip()
        if analysis:
            message = f"{message}\n\n{analysis}"

        results.append(
            {
                "ruleId": rule_id,
                "level": LEVEL_BY_SEVERITY.get(
                    str(f.get("Severity", "")).upper(), "warning"
                ),
                "message": {"text": message},
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {"uri": uri},
                            # ★ここが cm の SARIF に欠けている★
                            "region": {"startLine": start_line, "endLine": end_line},
                        }
                    }
                ],
                "partialFingerprints": {"codemenderFindingV1": fingerprint},
                "properties": {
                    "confidence": f.get("Confidence"),
                    "status": f.get("Status"),
                    "findingId": f.get("FindingID"),
                },
            }
        )

    if skipped_unresolved:
        print(
            f"[cm_to_sarif] リポジトリ内に解決できない finding を {skipped_unresolved} 件除外しました",
            file=sys.stderr,
        )

    return {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "CodeMender",
                        "version": tool_version,
                        "informationUri": "https://docs.cloud.google.com/gemini-enterprise-agent-platform/codemender",
                        "rules": list(rules.values()),
                    }
                },
                "results": results,
                # Conversion accounting, so a silent "converted nothing" is visible.
                "properties": {
                    "codemender": {
                        "input": len(findings),
                        "considered": considered,
                        "converted": len(results),
                        "unresolved": skipped_unresolved,
                    }
                },
            }
        ],
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--repo-root",
        default=os.environ.get("GITHUB_WORKSPACE") or ".",
        help="リポジトリのルート（uri をこれ基準の相対パスにする）",
    )
    ap.add_argument("--tool-version", default="0.5.0")
    ap.add_argument(
        "-i", "--input", default="-", help="cm report --format json の出力（既定: 標準入力）"
    )
    args = ap.parse_args()

    raw = sys.stdin.read() if args.input == "-" else Path(args.input).read_text("utf-8")
    if not raw.strip():
        print("[cm_to_sarif] 入力が空です", file=sys.stderr)
        return 1

    findings = load_findings(raw)

    sarif = build_sarif(findings, Path(args.repo_root), args.tool_version)
    acct = sarif["runs"][0]["properties"]["codemender"]

    # ★ガード★ 対象があるのに 1 件も変換できないのは、ほぼ確実に cm の出力
    # スキーマが変わったサイン（実測: 0.6.0 の snake_case 化で全滅した）。
    # 空の SARIF を黙ってアップロードして緑にしない。
    if acct["considered"] > 0 and acct["converted"] == 0:
        print(
            f"[cm_to_sarif] ERROR: {acct['considered']} 件の finding があるのに 1 件も"
            " SARIF に変換できなかった。cm の JSON スキーマが変わった可能性が高い"
            " (scripts/cm_findings.py の KEY_MAP を確認すること)。",
            file=sys.stderr,
        )
        return 2

    json.dump(sarif, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
    print(f"[cm_to_sarif] {acct['converted']} 件を SARIF に変換しました", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
