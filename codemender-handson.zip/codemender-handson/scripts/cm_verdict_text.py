#!/usr/bin/env python3
"""Single source of truth for how a CodeMender verdict is worded.

The verdict -- did an exploit actually run and succeed, or was the finding proven
unexploitable? -- is the entire reason to use this tool. It is surfaced in two
places that must never drift apart:

  * cm_annotate_alerts.py -- annotates an existing Code Scanning alert
  * cm_pr_verdict.py      -- posts a comment on a pull request

Keeping the load-bearing phrases here guarantees both render the same judgement.

Customer-facing text is Japanese by design; the audience is the workshop
attendee. Code comments are English per the repo's convention.
"""

from __future__ import annotations

# cm records its judgement in info.yaml's `status` field:
#   "valid"   -> an exploit was written, run, and it worked (VERIFIED)
#   "invalid" -> an exploit was attempted and could not succeed (DISMISSED)
# anything else is inconclusive (timeout, error, empty session).
STATUS_VALID = "valid"
STATUS_INVALID = "invalid"

VERIFIED = "VERIFIED"
DISMISSED = "DISMISSED"
UNKNOWN = "UNKNOWN"

# The load-bearing phrases. Do not reword casually: unit tests and customer-facing
# docs quote them, and the alert annotator and the PR commenter must stay identical.
VERIFIED_PHRASE = "悪用可能と確認"  # an exploit ran and succeeded
DISMISSED_PHRASE = "悪用不可能（偽陽性）と判定"  # an exploit was attempted and failed


def label_for_status(status: str) -> str:
    """Map cm info.yaml `status` to a normalized verdict label."""
    if status == STATUS_VALID:
        return VERIFIED
    if status == STATUS_INVALID:
        return DISMISSED
    return UNKNOWN
