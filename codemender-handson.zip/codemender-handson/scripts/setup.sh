#!/usr/bin/env bash
#
# CodeMender ハンズオン セットアップ オーケストレータ
#
#   ./scripts/setup.sh [PROJECT_ID]
#
# PROJECT_ID を省略した場合は gcloud config の値を使う。
# 各ステップは冪等。途中で失敗しても再実行してよい。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
export SCRIPT_DIR REPO_ROOT

PROJECT_ID="${1:-$(gcloud config get-value project 2>/dev/null || true)}"
if [[ -z "${PROJECT_ID}" || "${PROJECT_ID}" == "(unset)" ]]; then
  echo "[setup] ERROR: PROJECT_ID を指定するか gcloud config set project を実行してください" >&2
  exit 1
fi
export PROJECT_ID

banner() {
  echo
  echo "===================================================================="
  echo "  $*"
  echo "===================================================================="
}

banner "CodeMender ハンズオン セットアップ"
echo "[setup] PROJECT_ID = ${PROJECT_ID}"
echo "[setup] REPO_ROOT  = ${REPO_ROOT}"

banner "0/6  Git リポジトリの初期化（ZIP 展開時に必要）"
# ★ZIP で配布された場合 .git が存在しない★
# 教材は git を前提にしている:
#   - cm find / verify / fix は開始時に VCS reset する
#   - cm vcs diff でパッチをレビューする（Lab 3 の中心）
#   - cm vcs reset --force で元に戻す
# git が無いと Lab 3 が成立しないので、ここで初期化する。冪等。
if [[ -d "${REPO_ROOT}/.git" ]]; then
  echo "[setup] git リポジトリは既に存在します"
else
  echo "[setup] .git が無いため初期化します（ZIP 展開時の想定）"
  git -C "${REPO_ROOT}" init -q -b main
  git -C "${REPO_ROOT}" add -A
  git -C "${REPO_ROOT}" \
      -c user.email="workshop@example.com" \
      -c user.name="CodeMender Workshop" \
      commit -qm "baseline: workshop starting point"
  echo "[setup] 初回コミットを作成しました（cm vcs reset の戻り先になります）"
fi

banner "1/6  CodeMender CLI (cm) の導入"
"${SCRIPT_DIR}/01_install_cm.sh"

banner "2/6  必要な API の有効化"
"${SCRIPT_DIR}/02_enable_apis.sh"

banner "3/6  認証 (ADC) の設定"
"${SCRIPT_DIR}/03_setup_adc.sh"

banner "4/6  教材アプリのブートストラップ"
"${SCRIPT_DIR}/04_bootstrap_app.sh"

banner "5/6  既存 SAST ベースラインの生成"
"${SCRIPT_DIR}/05_run_baseline_sast.sh"

banner "6/6  作業ツリーを整える"
# ★重要★ 05 が baseline/*.json / *.sarif を再生成する。これらは追跡ファイルなので
# タイムスタンプ差だけでも作業ツリーが汚れる。
# cm find / verify / fix は開始時に git clean -fd するため、汚れたまま進むと
# 99_smoke_test.sh が「未コミットの変更があります」で停止する（実測）。
# ここでコミットして、これを cm vcs reset の戻り先にする。
if [[ -n "$(git -C "${REPO_ROOT}" status --porcelain)" ]]; then
  echo "[setup] セットアップで生成された差分をコミットします"
  git -C "${REPO_ROOT}" add -A
  git -C "${REPO_ROOT}" \
      -c user.email="workshop@example.com" \
      -c user.name="CodeMender Workshop" \
      commit -qm "setup: regenerated SAST baseline for this environment"
  echo "[setup] 完了。作業ツリーはクリーンです"
else
  echo "[setup] 作業ツリーは既にクリーンです"
fi

banner "セットアップ完了"
cat <<'EOF'
[setup] 次のコマンドで環境を確認してください:

    cm init --verify

[setup] この時点では「6 passed, 2 warnings」が正常です。
[setup]   - Server connectivity: Skipped … 常に出るもので異常ではありません
[setup]   - State database: Not yet created … 初回スキャンで作成されます
[setup] 初回スキャン後は「7 passed, 1 warnings」になります。
[setup]
[setup] 続いて ./scripts/99_smoke_test.sh で疎通を確認してください。
EOF
