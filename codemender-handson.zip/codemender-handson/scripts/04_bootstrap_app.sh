#!/usr/bin/env bash
#
# 教材アプリの依存関係を入れ、テストが通る状態を作る。
#
# ここで「全部グリーン」を確認しておくことが重要。
# Lab 3 で cm fix が機能を壊していないことを判定する基準線になる。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
cd "${REPO_ROOT}"

if ! command -v uv >/dev/null 2>&1; then
  echo "[04_bootstrap_app] uv を導入します"
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="${HOME}/.local/bin:${PATH}"
fi

echo "[04_bootstrap_app] 依存関係を解決します"
# 社給端末など、既定の index が社内リポジトリに向いている環境向けのフォールバック。
if ! uv sync --quiet 2>/dev/null; then
  echo "[04_bootstrap_app] 既定の index で失敗しました。PyPI にフォールバックします。"
  UV_DEFAULT_INDEX="https://pypi.org/simple" uv sync --quiet
fi

echo "[04_bootstrap_app] Python テストを実行します"
uv run --no-sync pytest -q

echo "[04_bootstrap_app] C（ASAN）テストを実行します"
if command -v cc >/dev/null 2>&1 || command -v clang >/dev/null 2>&1; then
  make -C native test >/dev/null && echo "[04_bootstrap_app] native テスト OK"
else
  echo "[04_bootstrap_app] WARN: C コンパイラが見つかりません。ボーナスラボはスキップされます。"
fi

echo "[04_bootstrap_app] 完了: 基準線はすべてグリーンです"
