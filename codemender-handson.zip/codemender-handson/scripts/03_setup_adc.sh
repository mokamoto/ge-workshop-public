#!/usr/bin/env bash
#
# Application Default Credentials (ADC) を設定し、
# CodeMender の設定ファイルを配置する。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
PROJECT_ID="${PROJECT_ID:-$(gcloud config get-value project)}"

ADC_PATH="${HOME}/.config/gcloud/application_default_credentials.json"
CM_HOME="${HOME}/.codemender"
CM_CONFIG="${CM_HOME}/config.yaml"

# --- ADC ---------------------------------------------------------------
#
# ★注意★ ADC ファイルの有無で判定してはいけない。
# Cloud Shell では application_default_credentials.json が存在しないまま
# ADC が利用可能（メタデータサーバ経由）。ファイルの有無で判定すると
# 不要な対話ログインを要求してしまう。実際にトークンが取れるかで判定する。
if gcloud auth application-default print-access-token >/dev/null 2>&1; then
  if [[ -f "${ADC_PATH}" ]]; then
    echo "[03_setup_adc] ADC は設定済み: ${ADC_PATH}"
  else
    echo "[03_setup_adc] ADC は利用可能（Cloud Shell 等の環境提供クレデンシャル）"
  fi
else
  echo "[03_setup_adc] ADC を設定します。ブラウザで認証してください。"
  gcloud auth application-default login --no-launch-browser
fi

# CodeMender が参照するプロジェクトを固定する。
# quota project の設定は ADC ファイルが無い環境では失敗するので、
# その場合は GOOGLE_CLOUD_PROJECT で明示する。
if [[ -f "${ADC_PATH}" ]]; then
  gcloud auth application-default set-quota-project "${PROJECT_ID}" 2>/dev/null \
    || echo "[03_setup_adc] WARN: quota project の設定に失敗しました（続行します）"
fi

echo "[03_setup_adc] ★シェルに以下を設定してください（Cloud Shell では必須）★"
echo "                export GOOGLE_CLOUD_PROJECT=${PROJECT_ID}"
if ! grep -qF "# codemender-handson PROJECT" "${HOME}/.bashrc" 2>/dev/null; then
  {
    echo ""
    echo "# codemender-handson PROJECT"
    echo "export GOOGLE_CLOUD_PROJECT=\"${PROJECT_ID}\""
  } >> "${HOME}/.bashrc"
  echo "[03_setup_adc] .bashrc に追記しました"
fi

# --- CodeMender ワークスペース ------------------------------------------
if [[ ! -d "${CM_HOME}" ]]; then
  echo "[03_setup_adc] cm init を実行します"
  cm init
fi

# 既存の設定は上書き前に退避する。
if [[ -f "${CM_CONFIG}" ]] && ! grep -q "codemender-handson" "${CM_CONFIG}"; then
  backup="${CM_CONFIG}.bak.$(date +%Y%m%d%H%M%S)"
  cp "${CM_CONFIG}" "${backup}"
  echo "[03_setup_adc] 既存の config.yaml を退避しました: ${backup}"
fi

# ワークショップ用設定をレポジトリのパスに合わせて配置する。
sed "s|__REPO_ROOT__|${REPO_ROOT}|g" \
  "${REPO_ROOT}/config/codemender-config.yaml" > "${CM_CONFIG}"

echo "[03_setup_adc] 設定を配置しました: ${CM_CONFIG}"

# エージェントのシェルコマンドの禁止リストを配置する。
# project_paths はファイル読み取りツールしか止めないため、これが無いと
# エージェントは cat / grep で TUTORIAL.md や expected/（ラボの答え）を読める（実測）。
# プロジェクト直下の .codemender/ には置かない（cm 0.11.0 は読み込まなかった）。
CM_POLICY="${CM_HOME}/command_policy.yaml"
if [[ -f "${CM_POLICY}" ]] && ! grep -q "codemender-handson\|workshop additions" "${CM_POLICY}"; then
  cp "${CM_POLICY}" "${CM_POLICY}.bak.$(date +%Y%m%d%H%M%S)"
  echo "[03_setup_adc] 既存の command_policy.yaml を退避しました"
fi
cp "${REPO_ROOT}/config/command_policy.yaml" "${CM_POLICY}"
echo "[03_setup_adc] コマンドの禁止リストを配置しました: ${CM_POLICY}"
echo "[03_setup_adc] 完了"
