#!/usr/bin/env python3
"""CodeMender の verify 結果を、既存の Code Scanning アラートに結びつける。

    uv run python scripts/cm_annotate_alerts.py \
        --fix-result /tmp/cm-nightly/fix_result.json \
        --repo cloud-gtm/codemender-handson \
        --mode link-only \
        --pr-url https://github.com/.../pull/21 \
        --summary-out /tmp/cm-nightly/alert_annotations.md

★狙い★ cm find が独自に検出した finding を Security タブに並べるだけでは、
「もう一個のスキャナ」にしか見えない。それより、**顧客が既に見ている
CodeQL（や取り込んだ bandit）のアラートに、実際に攻撃して確かめた結果を
突き合わせる**ほうが説得力がある——「あなたの Security タブの、あなたの
既存ツールが出したその番号に、悪用できるかどうかの根拠が付く」という絵になる。

★モードは3つ★

- off                          : 何もしない
- link-only（既定）             : 対応するアラートを Job Summary / PR 本文に
                                  リンクするだけ。アラートの状態は一切変更しない
- auto-dismiss-false-positives : DISMISSED（偽陽性）と判定した finding に対応する
                                  アラートを、根拠付きで実際に dismiss する
                                  （GitHub 側で人間がいつでも reopen できる）

**既定は link-only。** dismiss は「人の目から隠す」操作であり、このリポジトリの
一貫した設計（cm は commit しない、必須マージゲートにしない、等）に合わせて、
既定では踏み込まない。auto-dismiss-false-positives は明示的に選んだときだけ。

★マッチングは近似★ CodeQL と CodeMender は同じ脆弱性でも指す行番号が
数行ずれることがあり、CodeMender 自身も実行のたびに行番号が微妙に揺れる
（実測）。同じファイルに候補が1件しかなければ行番号のずれを許容し、
複数あれば一番近い行を選ぶ。厳密な一致は保証しない——このモードが
link-only を既定にしている理由でもある（人間が最終確認する）。
"""

from __future__ import annotations

import argparse
import json
import pathlib
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from cm_to_sarif import _index_by_basename, to_repo_relative  # noqa: E402
from cm_verdict_text import DISMISSED_PHRASE, VERIFIED_PHRASE  # noqa: E402

REPO_ROOT = pathlib.Path(__file__).resolve().parent.parent
LINE_TOLERANCE = 20
DISMISSABLE_REASON = "false positive"

# 脆弱性の大分類を表すキーワード群。auto-dismiss で「同じファイルに1件だけ
# あるアラート」を無条件に閉じると、種類の違う本物のアラートを誤って
# dismiss しうる（実測想定: bandit の shell=True 由来の偽陽性判定で、同じ
# webhook.py にある CodeQL の SSRF アラートを閉じてしまう）。dismiss の前に
# finding とアラートが同じ大分類に属することを要求する。
_VULN_CLASSES: dict[str, tuple[str, ...]] = {
    "sqli": ("sql injection", "sql-injection", "sqli", "cwe-89"),
    "ssrf": ("ssrf", "server-side request forgery", "server side request forgery", "cwe-918"),
    "idor": ("idor", "object level authorization", "object-level authorization",
             "tenant", "broken access control", "authorization bypass",
             "cwe-639", "cwe-862", "cwe-863", "insecure direct object"),
    "cmdi": ("command injection", "os command", "shell=true", "subprocess", "cwe-78"),
    "xss": ("xss", "cross-site scripting", "cross site scripting", "cwe-79"),
    "path": ("path traversal", "directory traversal", "cwe-22"),
    "overflow": ("buffer overflow", "heap", "out-of-bounds", "cwe-122", "cwe-787"),
}


def _vuln_classes(text: str) -> set[str]:
    low = str(text).lower()
    return {name for name, kws in _VULN_CLASSES.items() if any(kw in low for kw in kws)}


def _same_vuln_class(finding: dict, alert: dict) -> bool:
    """finding とアラートが同じ脆弱性の大分類を指しているか。

    どちらからも分類が読み取れないときは False（安全側 = dismiss しない）。
    """
    finding_text = f"{finding.get('title', '')} {finding.get('notes', '')}"
    alert_text = f"{alert.get('rule_id', '')} {alert.get('rule_description', '')}"
    fclasses = _vuln_classes(finding_text)
    aclasses = _vuln_classes(alert_text)
    return bool(fclasses & aclasses)


def fetch_open_alerts(repo: str) -> list[dict]:
    """`gh api` 経由でオープンな Code Scanning アラートを取得する。"""
    proc = subprocess.run(
        ["gh", "api", f"repos/{repo}/code-scanning/alerts?state=open",
         "--paginate", "--jq", ".[]"],
        capture_output=True, text=True,
    )
    if proc.returncode != 0:
        print(f"[cm_annotate_alerts] アラート取得に失敗: {proc.stderr}", file=sys.stderr)
        return []
    alerts = []
    for line in proc.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        alerts.append(json.loads(line))
    return alerts


def extract_alert_info(raw: dict) -> dict:
    loc = raw["most_recent_instance"]["location"]
    return {
        "number": raw["number"],
        "path": loc.get("path", ""),
        "line": int(loc.get("start_line") or 0),
        "rule_id": raw.get("rule", {}).get("id", ""),
        "rule_description": raw.get("rule", {}).get("description", ""),
        "tool": raw.get("tool", {}).get("name", ""),
        "html_url": raw.get("html_url", ""),
    }


def find_matching_alert(finding_path: str, finding_line: int, alerts: list[dict]) -> dict | None:
    candidates = [a for a in alerts if a["path"] == finding_path]
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    candidates.sort(key=lambda a: abs(a["line"] - finding_line))
    closest = candidates[0]
    if abs(closest["line"] - finding_line) <= LINE_TOLERANCE:
        return closest
    return None


def build_annotations(
    findings: list[dict], alerts: list[dict], mode: str, pr_url: str | None,
) -> tuple[list[str], list[dict]]:
    """各 finding に対応するアラートを探し、サマリ行と dismiss アクションを作る。

    戻り値: (summary_lines, dismiss_actions)
    dismiss_actions は mode == "auto-dismiss-false-positives" のときだけ非空になる。
    """
    basename_index = _index_by_basename(REPO_ROOT)
    lines = ["## 既存 Code Scanning アラートとの突き合わせ", ""]
    dismiss_actions: list[dict] = []
    matched_any = False

    for f in findings:
        rel_path = to_repo_relative(str(f.get("file_path", "")), REPO_ROOT, basename_index)
        if rel_path is None:
            continue
        alert = find_matching_alert(rel_path, int(f.get("line") or 0), alerts)
        if alert is None:
            continue
        matched_any = True

        verdict = f.get("verify_status", "")
        title = f.get("title", "")
        if verdict == "VERIFIED":
            fix_note = (
                f"→ [修正 PR]({pr_url}) を参照" if f.get("fixed") and pr_url
                else "→ 修正は未生成"
            )
            lines.append(
                f"- **[#{alert['number']}]({alert['html_url']})** "
                f"({alert['tool']} / {alert['rule_id']}) — "
                f"CodeMender が実際に攻撃して**{VERIFIED_PHRASE}**（{title}）。{fix_note}"
            )
        elif verdict == "DISMISSED":
            reasoning = f.get("notes", "") or "実際に攻撃を試みたが再現しなかった"
            lines.append(
                f"- **[#{alert['number']}]({alert['html_url']})** "
                f"({alert['tool']} / {alert['rule_id']}) — "
                f"CodeMender が実際に攻撃を試み、**{DISMISSED_PHRASE}**"
                f"（{title}）。根拠: {reasoning}"
            )
            if mode == "auto-dismiss-false-positives":
                if _same_vuln_class(f, alert):
                    dismiss_actions.append({
                        "alert_number": alert["number"],
                        "comment": (
                            f"CodeMender が実際に攻撃を試みたが再現しなかった（偽陽性）。"
                            f"finding: {title}。{reasoning}"
                        ),
                    })
                else:
                    # 同じファイルに紐づいたが脆弱性の種類が違う。別の本物アラートを
                    # 誤って閉じないよう、dismiss せずリンクだけ残して人間に委ねる。
                    lines.append(
                        f"  - ⚠️ 上記アラートは種類が一致しないため **auto-dismiss しない**"
                        f"（アラート: {alert['rule_id']} / finding: {title}）。人間が確認すること"
                    )

    if not matched_any:
        lines.append("対応する既存アラートは見つからなかった。")
    if mode == "link-only":
        lines.append("")
        lines.append(
            "> `alert_mode: link-only`（既定）のため、アラートの状態は変更していない。"
            " 上のリンクから内容を確認し、必要なら人間が dismiss すること。"
        )
    return lines, dismiss_actions


def dismiss_alert(repo: str, alert_number: int, comment: str) -> bool:
    proc = subprocess.run(
        [
            "gh", "api", "-X", "PATCH", f"repos/{repo}/code-scanning/alerts/{alert_number}",
            "-f", "state=dismissed",
            "-f", f"dismissed_reason={DISMISSABLE_REASON}",
            "-f", f"dismissed_comment={comment}",
        ],
        capture_output=True, text=True,
    )
    if proc.returncode != 0:
        print(f"[cm_annotate_alerts] alert #{alert_number} の dismiss に失敗: {proc.stderr}", file=sys.stderr)
        return False
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fix-result", required=True)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--mode", choices=["off", "link-only", "auto-dismiss-false-positives"], default="link-only")
    ap.add_argument("--pr-url", default=None)
    ap.add_argument("--summary-out", required=True)
    args = ap.parse_args()

    if args.mode == "off":
        pathlib.Path(args.summary_out).write_text("")
        return 0

    findings = json.loads(pathlib.Path(args.fix_result).read_text())
    raw_alerts = fetch_open_alerts(args.repo)
    alerts = [extract_alert_info(a) for a in raw_alerts]

    summary_lines, dismiss_actions = build_annotations(findings, alerts, args.mode, args.pr_url)

    for action in dismiss_actions:
        if dismiss_alert(args.repo, action["alert_number"], action["comment"]):
            print(f"[cm_annotate_alerts] alert #{action['alert_number']} を dismiss した", file=sys.stderr)

    pathlib.Path(args.summary_out).write_text("\n".join(summary_lines) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
