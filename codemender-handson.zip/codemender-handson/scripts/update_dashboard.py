#!/usr/bin/env python3
"""Append one nightly-run record to the dashboard's history.json.

    uv run python scripts/update_dashboard.py \
        --report /tmp/cm-nightly/report.json \
        --fix-result /tmp/cm-nightly/fix_result.json \
        --run-number 42 --run-url https://... --dry-run false \
        --history docs/dashboard/history.json \
        --out docs/dashboard/history.json

Kept deliberately small: one JSON array, capped at MAX_RECORDS entries,
rendered by a static docs/dashboard/index.html with no build step and
no external dependencies.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys
from datetime import datetime, timezone

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from cm_findings import normalize_findings  # noqa: E402
from cm_triage import finding_source  # noqa: E402

MAX_RECORDS = 90


def load_json(path: str | None) -> list[dict]:
    if not path or not pathlib.Path(path).exists():
        return []
    raw = pathlib.Path(path).read_text().strip()
    if not raw:
        return []
    data = json.loads(raw)
    if isinstance(data, dict):
        data = data.get("findings", [])
    return data


_TOTAL_TOKENS_RE = re.compile(r"Total tokens consumed:\s*([0-9.]+\s*[kKmM]?)")


def parse_token_amount(text: str) -> int | None:
    """'96.2k' -> 96200, '1.2M' -> 1200000, '850' -> 850. None if unparseable."""
    t = str(text or "").strip().replace(",", "")
    m = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)\s*([kKmM]?)", t)
    if not m:
        return None
    n = float(m.group(1)) * {"": 1, "k": 1_000, "m": 1_000_000}[m.group(2).lower()]
    return int(round(n))


def scan_tokens_from_logs(paths: list[str]) -> int | None:
    """Sum every `Total tokens consumed: X` line printed by `cm find` (deep / diff).

    `cm stats` does not count these scans (measured on cm 0.11.0), so the totals
    are read from the scan output itself. None when no log has the line.
    """
    total, seen = 0, False
    for path in paths or []:
        f = pathlib.Path(path)
        if not f.exists():
            continue
        for m in _TOTAL_TOKENS_RE.finditer(f.read_text(errors="replace")):
            n = parse_token_amount(m.group(1))
            if n is not None:
                total += n
                seen = True
    return total if seen else None


def verify_fix_tokens_from_stats(text: str) -> int | None:
    """TOTAL of the `total` row in `cm stats` output (verify/fix sessions)."""
    header = None
    for line in str(text or "").splitlines():
        cols = line.split()
        if not cols:
            continue
        if cols[0] == "COMMAND" and "TOTAL" in cols:
            header = cols
        elif header and cols[0] == "total":
            idx = header.index("TOTAL")
            if idx < len(cols):
                return parse_token_amount(cols[idx])
    return None


def build_record(
    findings: list[dict],
    fix_results: list[dict],
    run_number: str,
    run_url: str,
    dry_run: bool,
    status: str = "success",
    report_present: bool = True,
    canary_ok: bool = True,
    cm_version: str = "",
    scan_mode: str = "",
    tokens_scan: int | None = None,
    tokens_verify_fix: int | None = None,
) -> dict:
    severity_counts: dict[str, int] = {}
    for f in findings:
        sev = str(f.get("Severity", "UNKNOWN")).upper()
        severity_counts[sev] = severity_counts.get(sev, 0) + 1

    own = sum(1 for f in findings if finding_source(f.get("Title", "")) == "CodeMender")
    imported = len(findings) - own

    # NB: do not reuse the name `status` here. It shadowed the job-status
    # parameter, so the first real run (verify results present) was recorded as
    # status="VERIFIED", ok=False, and the dashboard drew it as a failed run.
    verify_counts: dict[str, int] = {}
    for r in fix_results:
        vstatus = r.get("verify_status") or "NOT_VERIFIED"
        verify_counts[vstatus] = verify_counts.get(vstatus, 0) + 1

    fixed_count = sum(1 for r in fix_results if r.get("fixed"))

    # ジョブが失敗している、または report.json が生成されていない run を
    # 「検出 0 件の成功」として記録しない。0 件を成功として並べると、
    # 認証や cm find が壊れている週がダッシュボード上は「きれい」に見える。
    # A run that saw none of this repo's seeded vulnerabilities is broken, not
    # clean (see scripts/cm_canary.py); it must not be drawn as a healthy run.
    ok = status == "success" and report_present and canary_ok

    return {
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "run_number": run_number,
        "run_url": run_url,
        "dry_run": dry_run,
        "status": status,
        "report_present": report_present,
        "canary_ok": canary_ok,
        "ok": ok,
        "cm_version": cm_version or None,
        "scan_mode": scan_mode or None,
        "tokens_scan": tokens_scan,
        "tokens_verify_fix": tokens_verify_fix,
        "tokens_total": (
            None if tokens_scan is None and tokens_verify_fix is None
            else (tokens_scan or 0) + (tokens_verify_fix or 0)
        ),
        "findings_total": len(findings),
        "findings_by_severity": severity_counts,
        "findings_own": own,
        "findings_imported": imported,
        "verify_counts": verify_counts,
        "fixed_count": fixed_count,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--report", required=True)
    ap.add_argument("--fix-result", default=None)
    ap.add_argument("--run-number", required=True)
    ap.add_argument("--run-url", required=True)
    ap.add_argument("--dry-run", default="false")
    ap.add_argument("--status", default="success",
                    help="GitHub の job.status（success/failure/cancelled）")
    ap.add_argument("--canary-file", default=None,
                    help="JSON from scripts/cm_canary.py; missing file counts as OK")
    ap.add_argument("--cm-version", default="", help="`cm --version` (last field)")
    ap.add_argument("--scan-mode", default="", help="quick / deep / diff")
    ap.add_argument("--scan-log", action="append", default=[],
                    help="cm find output to read 'Total tokens consumed' from (repeatable)")
    ap.add_argument("--stats-file", default=None, help="`cm stats` output for verify/fix tokens")
    ap.add_argument("--history", required=True, help="Existing history.json (may not exist yet)")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    report_present = bool(args.report) and pathlib.Path(args.report).exists() \
        and pathlib.Path(args.report).read_text().strip() not in ("", "[]")
    findings = normalize_findings(load_json(args.report))
    fix_results = load_json(args.fix_result)
    dry_run = args.dry_run.strip().lower() == "true"
    status = args.status.strip().lower() or "success"

    canary_ok = True
    if args.canary_file and pathlib.Path(args.canary_file).exists():
        try:
            canary_ok = bool(json.loads(pathlib.Path(args.canary_file).read_text()).get("canary_ok", True))
        except (OSError, ValueError):
            canary_ok = True

    stats_text = ""
    if args.stats_file and pathlib.Path(args.stats_file).exists():
        stats_text = pathlib.Path(args.stats_file).read_text(errors="replace")

    record = build_record(
        findings, fix_results, args.run_number, args.run_url, dry_run,
        status=status, report_present=report_present, canary_ok=canary_ok,
        cm_version=args.cm_version.strip(), scan_mode=args.scan_mode.strip(),
        tokens_scan=scan_tokens_from_logs(args.scan_log),
        tokens_verify_fix=verify_fix_tokens_from_stats(stats_text),
    )

    history = load_json(args.history)
    if not isinstance(history, list):
        history = []
    history.append(record)
    history = history[-MAX_RECORDS:]

    out_path = pathlib.Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(history, ensure_ascii=False, indent=2) + "\n")

    print(f"[update_dashboard] {len(history)} 件の履歴（今回: findings={len(findings)}, fixed={record['fixed_count']}）", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
