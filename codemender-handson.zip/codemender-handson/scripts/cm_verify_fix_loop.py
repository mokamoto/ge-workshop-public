#!/usr/bin/env python3
"""candidates.json の finding を1件ずつ verify し、本物だけ fix してコミットする。

    uv run python scripts/cm_verify_fix_loop.py \
        --candidates candidates.json \
        --model gemini-3.8-flash \
        --build-command scripts/verify.sh \
        --summary-out fix_summary.md \
        --result-out fix_result.json

★この実装が前提にしている、実測済みの製品挙動★

1. `cm find` / `verify` / `fix` は開始時に必ず
   `git checkout HEAD -- . && git clean -fd` 相当でワークスペースを reset する。
   したがって **fix が成功するたびに即座に commit しないと、次の fix 呼び出しで
   前の fix のパッチが消える。** これはリポジトリの README/RUNBOOK に記載した
   実測の落とし穴で、この loop の核心的な設計制約になっている。

2. `cm report --format json` の `Status` は verify の結果を反映しないことがある
   （実測。TUTORIAL.md 3-9 参照）。**唯一信頼できるのは
   `~/.codemender/artifacts/<session>/info.yaml` の `status` フィールド。**
   `valid` = 悪用可能（VERIFIED）、`invalid` = 偽陽性（DISMISSED）。
   このスクリプトは verify のたびに artifacts ディレクトリの差分を取り、
   新しく増えたセッションの info.yaml だけを読む。

3. `security.protected_files` は書き込みを止めない（実測）。
   このスクリプトは fix のたびに `tests/**` への変更を検知し、
   コミットメッセージと最終サマリの両方で目立つように警告する。
   ブロックはしない — 正当なテスト更新もあるため。人間のレビューに委ねる。

4. 非決定的なので、このループ自体の成否も実行のたびに変わりうる。
   失敗した finding はスキップして次に進み、最後にまとめて報告する。
   どれか1件が失敗しても全体を止めない。
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from cm_triage import short_path  # noqa: E402

ARTIFACTS_ROOT = Path.home() / ".codemender" / "artifacts"

# ★実測（run 33150329139）★ git add -A は cm fix が変更したファイルだけでなく、
# ジョブのルートに元からある無関係な未追跡ファイルまで全部拾ってしまい、
# CLI インストール時の cm-linux-amd64.zip（17MB）と WIF の認証情報ファイル
# （gha-creds-*.json）を実際にコミットしてリモートへ push してしまった。
# 個別のファイル名を除外する deny-list では次に別の一時ファイルが増えたときに
# また同じ事故が起きるので、代わりに config/codemender-config.yaml の
# project_paths と同じ「cm が触ってよい場所」だけを許可する allow-list にする。
PROJECT_PATHS = ["app", "native", "tests", "scripts"]

# Files that must never ride along in a fix commit even when they appear under
# PROJECT_PATHS. Measured (run #30 / PR #49): cm ran the app from app/ during
# verify/fix and left a 57 KB SQLite temp database (app/tmpkptj2uo6.db) that
# `git add -A` then swept into the fix PR.
_JUNK_SUFFIXES = (".db", ".sqlite", ".sqlite3", ".pyc", ".pyo", ".log", ".tmp")
_JUNK_DIRS = ("__pycache__", ".pytest_cache", ".ruff_cache")


def _is_junk_path(name: str) -> bool:
    """True for build/runtime debris that a security fix never legitimately adds."""
    parts = Path(name).parts
    if any(d in parts for d in _JUNK_DIRS):
        return True
    return name.lower().endswith(_JUNK_SUFFIXES)


def run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
    print(f"[cm_verify_fix_loop] $ {' '.join(cmd)}", file=sys.stderr)
    return subprocess.run(cmd, text=True, **kw)


def git(*args: str) -> subprocess.CompletedProcess:
    return run(["git", *args], capture_output=True)


def cm(*args: str, cwd: str | None = None) -> subprocess.CompletedProcess:
    """`cm` をターゲットファイルのディレクトリから呼ぶ。

    ★実測（run 33144034138）★ import した finding は FilePath が
    ディレクトリ情報を落とすことがある（"app/reports.py" として import しても
    "reports.py" として扱われ、リポジトリルートから読めず失敗する）。
    skills/codemender/SKILL.md に書いたとおり、file_path のディレクトリから
    実行すればどちらの記録形式でも解決できる。git 呼び出しは対象外
    （git はどこから呼んでもリポジトリ全体に対して働くため、cwd を変えない）。
    """
    return run(["cm", *args], capture_output=True, cwd=cwd)


def assert_clean_tree() -> None:
    # ★実測（run 33145383749）★ --untracked-files=no を付けないと、
    # このジョブが最初から抱えている無害な未追跡ファイル（CLI インストール時の
    # cm-linux-amd64.zip、WIF の gha-creds-*.json など）だけで「汚れている」と
    # 誤判定し、1件目から一度も cm verify を呼ばずに RuntimeError になる。
    # ここで本当に検知したいのは「直前の fix を commit し忘れて残った、
    # 追跡ファイルへの変更」だけなので、未追跡ファイルは無視してよい。
    status = git("status", "--porcelain", "--untracked-files=no").stdout
    if status.strip():
        raise RuntimeError(
            "作業ツリーが汚れた状態で次の cm 呼び出しに入ろうとした。"
            " 直前の fix を commit するか reset し忘れている:\n" + status
        )


def snapshot_artifact_dirs() -> set[str]:
    if not ARTIFACTS_ROOT.exists():
        return set()
    return {p.name for p in ARTIFACTS_ROOT.iterdir() if p.is_dir()}


def read_verdict(finding_id: str, before: set[str]) -> dict | None:
    """verify 直後に新しく増えたセッションから、この finding の info.yaml を探す。"""
    if not ARTIFACTS_ROOT.exists():
        return None
    new_dirs = {p.name for p in ARTIFACTS_ROOT.iterdir() if p.is_dir()} - before
    for name in new_dirs:
        info_path = ARTIFACTS_ROOT / name / "info.yaml"
        if not info_path.exists():
            continue
        info = _parse_minimal_yaml(info_path.read_text())
        vid = str(info.get("vulnerability_id", ""))
        # ★空の vulnerability_id を持つ info.yaml に絶対マッチさせない★
        # verify がエラーで途中終了すると id 欄が空の info.yaml が残ることがある。
        # 空だと finding_id.startswith(vid[:8]) == finding_id.startswith("") で
        # 常に真になり、無関係なセッションの判定を誤読する（実測想定）。
        if not vid:
            continue
        # FindingID は cm report では短縮形（先頭8桁）で表示されるが、
        # 環境によりどちらの形で来るか断定できないため両方向で照合する。
        if vid.startswith(finding_id) or finding_id.startswith(vid[:8]):
            return info
    return None


def _parse_minimal_yaml(text: str) -> dict:
    """info.yaml はフラットな key: "value" 形式なので、依存無しで最低限読む。"""
    out: dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        out[key.strip()] = value.strip().strip('"')
    return out


# 「機能退行なし」の判定基盤そのもの。ここを書き換えたパッチは、テストを
# 通したのではなくテスト/ビルド定義を緩めた可能性があるので、必ず人間に見せる。
_GUARD_FILES = ("scripts/verify.sh", "Makefile", "native/Makefile")


def touched_tests(diff_names: list[str]) -> list[str]:
    """レビューで必ず目立たせるべき変更（テスト・検証基盤）を抽出する。"""
    flagged = []
    for n in diff_names:
        if n.startswith("tests/") or "/tests/" in n:
            flagged.append(n)
        elif n in _GUARD_FILES or n.endswith("/Makefile"):
            flagged.append(n)
        elif "test" in Path(n).name.lower() and n.endswith((".c", ".h")):
            flagged.append(n)  # native/test_csvparse.c 等
    return flagged


def process_one(candidate: dict, model: str, build_command: str) -> dict:
    fid = candidate["id"]
    result = {**candidate, "verify_status": None, "fixed": False, "touched_tests": [], "notes": ""}

    # ★実測（run 33144034138）★ import した finding は FilePath が
    # ディレクトリ情報を落として "reports.py" 単体になり、リポジトリルートから
    # 実行すると読めずに即失敗する。file_path のディレクトリから実行すれば
    # どちらの記録形式でも解決できる（skills/codemender/SKILL.md 参照）。
    file_path = str(candidate.get("file_path", ""))
    work_dir = str(Path(file_path).parent) if file_path else None
    if work_dir in ("", "."):
        work_dir = None

    assert_clean_tree()
    before = snapshot_artifact_dirs()
    verify_proc = cm("verify", fid, "-y", "--bypass-warning", "--model", model, cwd=work_dir)
    verdict = read_verdict(fid, before)

    if verdict is None:
        # ★実測（run 33143578060）★ ここに来たときに cm verify 自身が何を
        # 言っていたのか分からないと調査できない。標準出力・エラーを必ず残す。
        print(f"[cm_verify_fix_loop] cm verify の出力 (exit={verify_proc.returncode}):", file=sys.stderr)
        print(verify_proc.stdout, file=sys.stderr)
        print(verify_proc.stderr, file=sys.stderr)
        result["notes"] = (
            "info.yaml が見つからなかった（verify がタイムアウトしたか、"
            "セッションIDの突き合わせに失敗した可能性、あるいは verify 自体が"
            f"即時エラー終了した可能性。exit={verify_proc.returncode}）。手動確認が必要。"
        )
        result["verify_status"] = "UNKNOWN"
        # verify が何を書いたか分からない状態なので、安全側に倒して reset する。
        git("checkout", "HEAD", "--", ".")
        git("clean", "-fd", "-e", "gha-creds-*.json")  # WIF の認証ファイルを消さない
        return result

    status = verdict.get("status", "")
    result["verify_status"] = "VERIFIED" if status == "valid" else "DISMISSED"
    result["confidence"] = verdict.get("confidence", "")

    if status != "valid":
        result["notes"] = "偽陽性と判定された。fix はしない（この製品の核心的な価値）。"
        return result

    # ★ここが本題★ VERIFIED のものだけ fix する。
    fix_proc = cm("fix", fid, "-y", "--bypass-warning", "--model", model, cwd=work_dir)
    if fix_proc.returncode != 0:
        result["notes"] = f"cm fix が失敗した: {fix_proc.stderr[-500:]}"
        git("checkout", "HEAD", "--", ".")
        git("clean", "-fd", "-e", "gha-creds-*.json")  # WIF の認証ファイルを消さない
        return result

    # ★実測（run 33148225680）★ cm fix は実際にファイルを書き換えていたが
    # （search_and_replace ツールで app/reports.py を変更、26分の本物のセッション）、
    # git add でステージされていなかった（unstaged diff: ['app/reports.py']）。
    # file_path のディレクトリ（cwd=work_dir）から呼んだことで、cm 内部の
    # サンドボックスがリポジトリ全体を見せていない可能性がある。原因を cm 側の
    # 内部実装まで追うより、ここで確実に git add することで、cm の内部
    # ステージングが効いても効かなくても同じ結果になるようにする。
    #
    # ★実測（run 33150329139、事故）★ 最初は git add -A にしていたが、
    # ジョブのルートにある無関係な未追跡ファイル（CLI インストール時の
    # cm-linux-amd64.zip、WIF の認証情報ファイル gha-creds-*.json）まで
    # 拾ってコミット・push してしまった。PROJECT_PATHS だけを対象にした
    # allow-list に変える。
    #
    # ★実測（cm 0.5.0）★ cm fix は project_paths 内に enforced-ignore の
    # 未追跡 .gitignore（node_modules/venv 等）を落とす。これを allow-list の
    # git add が拾って修正 PR に混ぜてしまうので、cm が新規に作った（＝未追跡の）
    # .gitignore だけ、staging 前に消しておく。リポジトリ管理下の .gitignore は触らない。
    for d in PROJECT_PATHS:
        gi = Path(d) / ".gitignore"
        if gi.exists() and git("ls-files", "--error-unmatch", str(gi)).returncode != 0:
            gi.unlink()

    # 存在しないパスを pathspec に混ぜると git add が
    # "did not match any files" で全体を失敗させ、実在するパスも
    # 何一つステージされなくなるため、実在するものだけに絞る。
    existing_paths = [p for p in PROJECT_PATHS if Path(p).exists()]
    if existing_paths:
        git("add", "-A", "--", *existing_paths)

    # Drop newly *added* debris (temp databases, caches) from the index and the
    # tree. Only files git considers new are inspected, so a tracked file that a
    # fix legitimately modifies is never touched by this filter.
    added = git("diff", "--cached", "--name-only", "--diff-filter=A").stdout.splitlines()
    junk = [n for n in added if _is_junk_path(n)]
    for n in junk:
        git("reset", "-q", "--", n)
        Path(n).unlink(missing_ok=True)
    if junk:
        print(f"[cm_verify_fix_loop] dropped debris from the fix: {junk}", file=sys.stderr)

    diff_names = git("diff", "--cached", "--name-only").stdout.splitlines()
    if not diff_names:
        # VERIFIED のうえ cm fix が exit 0 で終わり、git add -A した後も
        # まだ差分が無いケース。cm fix 自身の出力を残す。
        unstaged = git("diff", "--name-only").stdout.splitlines()
        print(f"[cm_verify_fix_loop] cm fix の出力 (exit={fix_proc.returncode}):", file=sys.stderr)
        print(fix_proc.stdout, file=sys.stderr)
        print(fix_proc.stderr, file=sys.stderr)
        print(f"[cm_verify_fix_loop] unstaged diff (git add -A 後): {unstaged}", file=sys.stderr)
        result["notes"] = (
            "cm fix が終了したが git add -A 後も差分が無い"
            f"{'（unstaged ' + str(unstaged) + '）' if unstaged else ''}。"
        )
        git("checkout", "HEAD", "--", ".")
        git("clean", "-fd", "-e", "gha-creds-*.json")
        return result

    build_proc = run([build_command], capture_output=True)
    if build_proc.returncode != 0:
        # Keep the cell-sized reason and the long build log apart: the log goes
        # under a <details> block in the summary, never into the Markdown table
        # (a multi-line cell with '|' characters shattered PR #49's table).
        result["notes"] = "パッチがビルド/テストを壊したため破棄した（ビルド/テスト出力は下の折りたたみ）"
        result["build_output"] = build_proc.stdout[-800:]
        git("reset", "--hard", "HEAD")  # ★このパッチだけ確実に消す★
        return result

    result["touched_tests"] = touched_tests(diff_names)
    subject = f"fix(security): {candidate.get('title', fid)} ({fid})"
    body_lines = [f"Severity: {candidate.get('severity', '')}"]
    if result["touched_tests"]:
        body_lines.append(
            "⚠️ このパッチはテストファイルも変更している。"
            " protected_files は書き込みを防がないので、人間が必ず確認すること: "
            + ", ".join(result["touched_tests"])
        )
    commit = git("commit", "-m", subject, "-m", "\n".join(body_lines))
    if commit.returncode != 0:
        result["notes"] = f"git commit に失敗した: {commit.stderr}"
        git("reset", "--hard", "HEAD")
        return result

    result["fixed"] = True
    result["commit"] = git("rev-parse", "HEAD").stdout.strip()
    return result


def _cell(text: object, limit: int = 160) -> str:
    """One-line, pipe-safe Markdown table cell."""
    flat = " ".join(str(text or "").split()).replace("|", "\\|")
    return flat if len(flat) <= limit else flat[: limit - 1] + "…"


def _detail_output(r: dict) -> str:
    """Long-form build/test output to show under the table, if any."""
    out = str(r.get("build_output") or "")
    if not out:
        # Older fix_result.json embedded the build log in `notes` after the first line.
        notes = str(r.get("notes") or "")
        if "\n" in notes:
            out = notes.split("\n", 1)[1]
    return out.strip()


def render_summary(results: list[dict]) -> list[str]:
    """Markdown for the PR body / job summary. Table cells are always one line."""
    fixed = [r for r in results if r.get("fixed")]
    dismissed = [r for r in results if r.get("verify_status") == "DISMISSED"]
    unresolved = [r for r in results if r.get("verify_status") in ("UNKNOWN", "ERROR")]
    any_tests_touched = any(r.get("touched_tests") for r in fixed)

    lines = [
        "## CodeMender 検証・修正結果",
        "",
        f"- verify した: {len(results)} 件",
        f"- 本物と判定して修正した (VERIFIED → fix → build 成功): **{len(fixed)}**",
        f"- 偽陽性として却下した (DISMISSED): {len(dismissed)}",
        f"- 判定できなかった / エラー: {len(unresolved)}",
    ]
    if any_tests_touched:
        lines.append("")
        lines.append(
            "> ⚠️ **少なくとも1件の修正がテストファイルも変更しています。"
            "必ず PR で確認してください。**"
        )
    lines.append("")
    lines.append("| ID | 重大度 | 判定 | 結果 | コミット |")
    lines.append("|---|---|---|---|---|")
    for r in results:
        commit = str(r.get("commit", ""))[:8]
        if r.get("touched_tests"):
            note = "テスト変更あり ⚠️"
        elif r.get("fixed"):
            note = "修正済み"
        else:
            note = str(r.get("notes") or "").split("\n", 1)[0]
        lines.append(
            f"| `{r['id']}` | {_cell(r.get('severity', ''))} | {_cell(r.get('verify_status', ''))} "
            f"| {_cell(note)} | `{commit}` |"
        )

    # Long outputs (a discarded patch's failing test log) live below the table,
    # collapsed, so they never break the Markdown grid.
    for r in results:
        out = _detail_output(r)
        if not out:
            continue
        lines += [
            "",
            f"<details><summary><code>{str(r['id'])[:8]}</code> のビルド/テスト出力（このパッチは破棄済み）</summary>",
            "",
            "```text",
            out,
            "```",
            "",
            "</details>",
        ]

    # Machine-readable "addressed findings" block: next night's cm_triage dedups
    # against this and only this, so unrelated findings are never skipped.
    if fixed:
        lines.append("")
        lines.append("<!-- cm-addressed")
        for r in fixed:
            # Repo-relative on purpose: the runner's absolute path is meaningless
            # elsewhere and would leak the CI workspace layout into the PR body.
            lines.append(f"{short_path(str(r.get('file_path', '')))}:{r.get('line', '')}")
        lines.append("-->")
    return lines


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidates", required=True)
    ap.add_argument("--model", default="gemini-3.8-flash")
    ap.add_argument("--build-command", required=True)
    ap.add_argument("--summary-out", required=True)
    ap.add_argument("--result-out", required=True)
    args = ap.parse_args()

    candidates = json.loads(Path(args.candidates).read_text())
    results = []
    for c in candidates:
        try:
            results.append(process_one(c, args.model, args.build_command))
        except RuntimeError as exc:
            results.append({
                **c, "verify_status": "ERROR", "fixed": False,
                "touched_tests": [], "notes": str(exc),
            })

    fixed = [r for r in results if r["fixed"]]

    Path(args.result_out).write_text(json.dumps(results, ensure_ascii=False, indent=2))
    lines = render_summary(results)
    Path(args.summary_out).write_text("\n".join(lines) + "\n")

    print(
        f"[cm_verify_fix_loop] {len(fixed)}/{len(results)} 件を修正・コミット済み",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
