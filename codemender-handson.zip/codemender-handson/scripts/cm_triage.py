#!/usr/bin/env python3
"""`cm report --format json` を読み、verify に回す候補を選ぶ。

    cm report --format json | uv run python scripts/cm_triage.py \
        --severity-min HIGH --max-verify 3 \
        --candidates-out candidates.json --summary-out summary.md

すべての finding は summary.md に出す（レポートとしての完全性）。
verify に回すのはそのうち上位 --max-verify 件だけ（コスト・時間の上限）。

すでに `codemender/nightly-*` ブランチの open PR で対応中の finding は、
毎晩トークンを消費して同じ結論を出し直さないよう除外する
（`gh pr list` が使えない環境では黙ってスキップする — 動作は変えない）。
"""

from __future__ import annotations

import argparse
import json
import pathlib
import re
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from cm_findings import load_findings as _load_normalized  # noqa: E402
from cm_to_sarif import _index_by_basename, to_repo_relative  # noqa: E402

REPO_ROOT = pathlib.Path(__file__).resolve().parent.parent
SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
DONE_STATUSES = {"FIXED", "DISMISSED"}

# bandit_to_cm.py は "[B602] subprocess_popen_with_shell_equals_true" のように
# タイトルの先頭に bandit の test_id を必ず付ける。これを手がかりに
# 「cm find が独自に見つけたもの」と「既存ツールから import したもの」を
# 見分ける。別のツールを import する場合はこの判定を調整すること。
_IMPORTED_TITLE_RE = re.compile(r"^\[B\d+\]")


def finding_source(title: str) -> str:
    return "bandit（既存ツール）" if _IMPORTED_TITLE_RE.match(str(title)) else "CodeMender"


def load_findings(raw: str) -> list[dict]:
    # cm report --format json はトップレベルが配列、または {"findings": [...]}
    # のどちらかで来る。さらに cm 0.6.0 でキーが snake_case に変わったので、
    # cm_findings で PascalCase に正規化してから読む（実測: 正規化無しでは
    # 12 件すべて Severity="" となり、1 件も verify 候補に上がらなかった）。
    return _load_normalized(raw)


# 修正 PR の本文には、その PR が実際に対応した finding の場所を機械可読な
# ブロックで埋め込む（cm_verify_fix_loop.py が fix_summary.md の末尾に出力する）。
#   <!-- cm-addressed
#   app/reports.py:73
#   -->
# dedup はこのブロックの中身だけを見る。トリアージ表（全 finding を載せる）を
# 突き合わせ対象にすると、PR に無関係な finding まで「対応中」と誤判定するため。
_ADDRESSED_RE = re.compile(r"<!--\s*cm-addressed\s*(.*?)-->", re.DOTALL)


def _normalized_location(file_path: str, line: object) -> str:
    """絶対パス・相対パス・ベース名のどれで来てもリポジトリ相対:行 に揃える。

    cm-native の finding は絶対パス、import した finding は相対パスと形式が
    まちまちなので（実測）、両側をこれで正規化してから比較する。
    """
    return f"{short_path(str(file_path))}:{line}"


def _addressed_locations(pr_body: str) -> set[str]:
    locations: set[str] = set()
    for block in _ADDRESSED_RE.findall(pr_body):
        for raw in block.splitlines():
            raw = raw.strip()
            if not raw or ":" not in raw:
                continue
            path, _, line = raw.rpartition(":")
            locations.add(_normalized_location(path, line))
    return locations


def fetch_addressed_locations() -> set[str]:
    """open な修正 PR（codemender/nightly-*）が対応済みの finding 場所を集める。

    gh が無い / 認証が無い / 失敗したときは空集合を返す（＝重複排除を諦めて
    素通しする。誤って finding を隠さない方に倒す）。取得は実行あたり 1 回だけ。
    """
    try:
        out = subprocess.run(
            [
                "gh", "pr", "list",
                "--state", "open",
                "--search", "head:codemender/nightly-",
                "--json", "body",
            ],
            capture_output=True, text=True, timeout=30, check=True,
        ).stdout
        prs = json.loads(out)
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError):
        return set()
    addressed: set[str] = set()
    for pr in prs:
        addressed |= _addressed_locations(pr.get("body", ""))
    return addressed


def finding_is_addressed(finding: dict, addressed: set[str]) -> bool:
    """この finding が、既存の修正 PR で対応済みの場所に一致するか。"""
    target = _normalized_location(finding.get("FilePath", ""), finding.get("StartLine", ""))
    if not target.strip(":"):
        return False
    return target in addressed


def short_path(file_path: str) -> str:
    """絶対パス（例: /home/runner/work/.../app/reports.py）をリポジトリ相対に縮める。

    実測: cm report --format json の FilePath は cm find 自身の finding では
    絶対パス、import した finding では相対パスと形式がまちまち。
    Job Summary の File 列がランナーの絶対パスで埋まって読めなくなるのを防ぐ。
    """
    basename_index = _index_by_basename(REPO_ROOT)
    rel = to_repo_relative(str(file_path), REPO_ROOT, basename_index)
    return rel if rel is not None else str(file_path)


def to_markdown_table(findings: list[dict], candidate_ids: set[str]) -> str:
    lines = [
        "> **Source** = 誰が見つけたか（`CodeMender` = `cm find` 自身の検出、"
        "`bandit（既存ツール）` = 既存 SAST から import したもの）。"
        " **Verify対象** に ✅ が付いているのが、今回 `cm verify` に回す上位 N 件。"
        " 残りは検出はしたが今回は verify していない（重大度が低い、または上限超過）。",
        "",
        "| ID | Source | Severity | Status | File | Title | Verify対象 |",
        "|---|---|---|---|---|---|---|",
    ]
    for f in findings:
        fid = str(f.get("FindingID", ""))
        title = f.get("Title", "")
        mark = "✅" if fid in candidate_ids else ""
        line = f.get("StartLine", "")
        location = f"{short_path(f.get('FilePath', ''))}:{line}" if line else short_path(f.get("FilePath", ""))
        lines.append(
            "| `{}` | {} | {} | {} | {} | {} | {} |".format(
                fid,
                finding_source(title),
                f.get("Severity", ""),
                f.get("Status", ""),
                location,
                str(title).replace("|", "\\|"),
                mark,
            )
        )
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--severity-min", default="HIGH", choices=list(SEVERITY_ORDER))
    ap.add_argument("--max-verify", type=int, default=3)
    ap.add_argument(
        "--reserve-import-slot", action="store_true",
        help="上位 N 枠に import した finding が 1 件も入らないとき、最下位の枠を"
             "最上位の import finding に譲る（既存 SAST のアラートを毎回 1 件は裁く）",
    )
    ap.add_argument("--candidates-out", required=True)
    ap.add_argument("--summary-out", required=True)
    ap.add_argument("-i", "--input", default="-")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.input == "-" else open(args.input).read()
    findings = load_findings(raw)

    floor = SEVERITY_ORDER[args.severity_min]
    qualifying = [
        f for f in findings
        if str(f.get("Status", "")).upper() not in DONE_STATUSES
        and SEVERITY_ORDER.get(str(f.get("Severity", "")).upper(), 99) <= floor
    ]
    addressed = fetch_addressed_locations()
    skipped_pending = [f for f in qualifying if finding_is_addressed(f, addressed)]
    skipped_ids = {id(f) for f in skipped_pending}
    verifiable = [f for f in qualifying if id(f) not in skipped_ids]
    # 重大度が同じときは CodeMender 自身の検出（信頼度 100%）を、import した
    # 既存ツールの finding より先に verify する。上限件数で打ち切ったときに、
    # 一番見せたい IDOR 等が「次回送り」になるのを防ぐ（実測: bandit の
    # hardcoded_tmp などが先に選ばれていた）。
    def _sort_key(f: dict) -> tuple[int, int]:
        severity = SEVERITY_ORDER.get(str(f.get("Severity", "")).upper(), 99)
        source_rank = 0 if finding_source(f.get("Title", "")) == "CodeMender" else 1
        return (severity, source_rank)

    verifiable.sort(key=_sort_key)

    candidates = verifiable[: args.max_verify]
    reserved_import = None
    # ★狙い★ 同点処理は CodeMender 独自の検出を優先するので、既存 SAST から
    # import した finding は上限で毎回押し出される（実測: run #30 で bandit の
    # exporter.py B602 が枠に入らず、夜間 PR に偽陽性の DISMISSED が一度も出ない）。
    # 「お客様の既存ツールが出したアラートを、実際に攻撃して裁く」のが最も
    # 刺さる絵なので、指定時は最下位の 1 枠を最上位の import finding に譲る。
    if args.reserve_import_slot and args.max_verify > 0:
        is_imported = lambda f: finding_source(f.get("Title", "")) != "CodeMender"  # noqa: E731
        if not any(is_imported(f) for f in candidates):
            reserved_import = next(
                (f for f in verifiable[args.max_verify:] if is_imported(f)), None
            )
            if reserved_import is not None:
                candidates = candidates[:-1] + [reserved_import]
    chosen = {id(f) for f in candidates}
    carried_over = [f for f in verifiable if id(f) not in chosen]
    candidate_ids = {str(f.get("FindingID", "")) for f in candidates}

    with open(args.candidates_out, "w") as fh:
        json.dump(
            [
                {
                    "id": str(f.get("FindingID", "")),
                    "title": f.get("Title", ""),
                    "severity": f.get("Severity", ""),
                    "file_path": f.get("FilePath", ""),
                    "line": f.get("StartLine", ""),
                }
                for f in candidates
            ],
            fh,
            ensure_ascii=False,
            indent=2,
        )

    own_count = sum(1 for f in findings if finding_source(f.get("Title", "")) == "CodeMender")
    imported_count = len(findings) - own_count

    summary = [
        "## CodeMender トリアージ結果",
        "",
        f"- 検出 {len(findings)} 件"
        f"（**CodeMender 自身の検出**: {own_count} 件 / **既存ツールから import**: {imported_count} 件）"
        f" / 重大度 {args.severity_min} 以上 {len(qualifying)} 件"
        f"（うち今回 verify するのは {len(candidates)} 件、上限 {args.max_verify}）",
        f"- 既存の未マージ PR で対応中のためスキップ: {len(skipped_pending)} 件",
        f"- 上限超過のため今回は見送り（次回の候補）: {len(carried_over)} 件",
    ] + ([
        f"- 既存ツールの finding を 1 件は必ず裁くため、`{reserved_import.get('FindingID', '')}`"
        f"（{finding_source(reserved_import.get('Title', ''))}）に 1 枠を予約した",
    ] if reserved_import is not None else []) + [
        "",
        to_markdown_table(findings, candidate_ids),
    ]
    with open(args.summary_out, "w") as fh:
        fh.write("\n".join(summary) + "\n")

    print(
        f"[cm_triage] {len(findings)} 件中 {len(candidates)} 件を verify 対象に選定",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
