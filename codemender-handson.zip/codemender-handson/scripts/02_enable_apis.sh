#!/usr/bin/env bash
#
# CodeMender が必要とする API を有効化する。
set -euo pipefail

PROJECT_ID="${PROJECT_ID:-$(gcloud config get-value project)}"

REQUIRED_APIS=(
  aiplatform.googleapis.com          # セッション管理とストリーミング
  cloudresourcemanager.googleapis.com # 認証とプロジェクトメタデータの検証
)

echo "[02_enable_apis] PROJECT_ID = ${PROJECT_ID}"

enabled="$(gcloud services list --enabled --project="${PROJECT_ID}" --format='value(config.name)')"

for api in "${REQUIRED_APIS[@]}"; do
  if printf '%s\n' "${enabled}" | grep -qx "${api}"; then
    echo "[02_enable_apis] 有効済み: ${api}"
  else
    echo "[02_enable_apis] 有効化します: ${api}"
    gcloud services enable "${api}" --project="${PROJECT_ID}"
  fi
done

echo "[02_enable_apis] 完了"
echo
echo "[02_enable_apis] 参考: CodeMender の実行には roles/aiplatform.user が必要です。"
echo "                 権限が無い場合はプロジェクト管理者に以下を依頼してください:"
echo
echo "  gcloud projects add-iam-policy-binding ${PROJECT_ID} \\"
echo "    --member=\"user:\$(gcloud config get-value account)\" \\"
echo "    --role=\"roles/aiplatform.user\""
