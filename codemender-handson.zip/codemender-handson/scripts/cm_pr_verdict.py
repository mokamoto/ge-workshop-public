#!/usr/bin/env python3
"""Post a CodeMender exploitability verdict as a pull-request comment.

CodeMender's value is that it does not guess. It writes and runs a real exploit,
then reports VERIFIED (the exploit worked) or DISMISSED (it tried and could not).
Today that verdict only reaches a human through the Security tab or the nightly
fix PR's body -- never in the conversation of the PR a developer just opened.
This script puts it there, next to whatever the AI code reviewers guessed.

It reads a `cm verify` artifact directory (info.yaml + REPORT.md + exploit.sh),
renders a Markdown comment, and posts it with `gh pr comment`.

Two sources of artifacts:

  --artifact-dir DIR   replay a specific directory. The demo points this at the
                       pre-captured expected/ artifacts so a customer-facing run
                       never depends on a flaky ~11-minute live verify.
  --source live        read the newest session under ~/.codemender/artifacts/,
                       optionally matched to --finding-id.

This never merges, approves, or presents a finding as resolved. cm's `-y` skips
confirmations; it never skips human review, and neither does this.

Usage:
    python scripts/cm_pr_verdict.py --pr 42 --artifact-dir expected/lab2_verify_v2
    python scripts/cm_pr_verdict.py --pr 42 --source live --finding-id f1277ee4
    python scripts/cm_pr_verdict.py --artifact-dir expected/lab2_verify_v2 --print
"""

from __future__ import annotations

import argparse
import pathlib
import re
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from cm_verdict_text import (  # noqa: E402
    DISMISSED,
    DISMISSED_PHRASE,
    VERIFIED,
    VERIFIED_PHRASE,
    label_for_status,
)

ARTIFACTS_ROOT = pathlib.Path.home() / ".codemender" / "artifacts"

# Redact operator-specific absolute paths so nothing machine-local leaks into a
# PR comment. cm artifacts embed the checkout path (e.g. /Users/<name>/...) and a
# scratch path (/private/tmp/cm-...). The workshop's own /tmp/cm-workshop/... paths
# are part of the false-positive explanation, so they are deliberately kept.
_ABS_PATH_RE = re.compile(r"""(/Users/[^\s"']+|/home/[^\s"']+|/private/tmp/[^\s"']+)""")

# Keep the exploit excerpt tidy in the comment; the full script lives in the run.
_MAX_EXPLOIT_LINES = 60

# A verdict-colored badge at the top of the comment, so it is identifiable at a
# glance even though the GITHUB_TOKEN author is a shared github-actions[bot].
# (When posted via a dedicated bot account's PAT, the author name/avatar differ too.)
_BADGE_COLOR = {VERIFIED: "d93025", DISMISSED: "1e8e3e"}


def _badge(label: str) -> str:
    color = _BADGE_COLOR.get(label, "9aa0a6")
    return f"![CodeMender {label}](https://img.shields.io/badge/CodeMender-{label}-{color})"


_FRAMING = (
    "多くのツールは finding を「たぶん脆弱」と *推測* するだけです。"
    "CodeMender は実際に攻撃コード（exploit）を書いて **走らせ**、"
    "本物か偽陽性かを *実証* しました。"
)

_NOT_A_CLAIM = (
    "> これはコードに対する主張ではありません。"
    "**アプリを実際に起動し、攻撃を走らせた結果です。**"
)

_NOT_A_GATE = (
    "> ⚠️ CodeMender は Pre-GA で、結果は実行ごとに揺れます（非決定的）。"
    "これは自動マージゲートではなく、トリアージの *支援* です。"
    "パッチや対応は必ず人間がレビューしてください。"
)


def redact(text: str) -> str:
    """Replace operator-specific absolute paths with a placeholder."""
    return _ABS_PATH_RE.sub("<redacted>", text)


def parse_info(text: str) -> dict:
    """Parse cm's info.yaml without a YAML dependency.

    info.yaml is flat `key: "value"` plus a couple of `- item` lists. PyYAML is
    intentionally not a project dependency (see scripts/cm_verify_fix_loop.py), so
    we read the scalar keys we need and collect the `vulnerability_tags` list.
    """
    scalars: dict[str, object] = {}
    tags: list[str] = []
    current_list_key: str | None = None
    for raw in text.splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("- "):
            if current_list_key == "vulnerability_tags":
                tags.append(stripped[2:].strip().strip('"'))
            continue
        if ":" not in stripped:
            continue
        key, _, value = stripped.partition(":")
        key = key.strip()
        value = value.strip().strip('"')
        # An empty value means a block list follows (e.g. `vulnerability_tags:`).
        # `[]` is an explicit empty inline list, which is not a block.
        current_list_key = key if value == "" else None
        if value != "":
            scalars[key] = value
    scalars["vulnerability_tags"] = tags
    return scalars


def executive_summary(report_md: str) -> str:
    """Return the prose under '## Executive Summary', up to the next heading."""
    out: list[str] = []
    capturing = False
    for line in report_md.splitlines():
        if line.strip().lower().startswith("## executive summary"):
            capturing = True
            continue
        if capturing and line.startswith("## "):
            break
        if capturing:
            out.append(line)
    return "\n".join(out).strip()


def _exploit_block(exploit_sh: str) -> str:
    """A redacted, length-capped excerpt of the exploit that ran."""
    lines = redact(exploit_sh).splitlines()
    if len(lines) > _MAX_EXPLOIT_LINES:
        lines = lines[:_MAX_EXPLOIT_LINES] + ["# ... (truncated; full script is in the run artifacts)"]
    return "\n".join(lines).strip()


def _metadata_table(label: str, status: str, confidence: str, severity: str) -> str:
    status_cell = f"**{label}**（`status: {status or 'unknown'}`）"
    rows = [
        "| 項目 | 値 |",
        "|---|---|",
        f"| 判定 | {status_cell} |",
        f"| 確信度 | `{confidence or 'n/a'}` |",
        f"| 深刻度 | `{severity or 'n/a'}` |",
    ]
    return "\n".join(rows)


def build_comment(artifact_dir: pathlib.Path) -> str:
    """Render the full PR-comment Markdown from a cm verify artifact directory."""
    artifact_dir = pathlib.Path(artifact_dir)
    info = parse_info((artifact_dir / "info.yaml").read_text(encoding="utf-8"))
    status = str(info.get("status", ""))
    label = label_for_status(status)
    title = str(info.get("vulnerability_title", "(no title)"))
    severity = str(info.get("severity", ""))
    confidence = str(info.get("confidence", ""))

    report_path = artifact_dir / "REPORT.md"
    summary = executive_summary(report_path.read_text(encoding="utf-8")) if report_path.exists() else ""
    summary = redact(summary)

    exploit_path = artifact_dir / "exploit.sh"
    exploit = _exploit_block(exploit_path.read_text(encoding="utf-8")) if exploit_path.exists() else ""

    table = _metadata_table(label, status, confidence, severity)

    if label == VERIFIED:
        header = f"## 🔴 CodeMender の判定: {VERIFIED_PHRASE}（VERIFIED）"
        details_summary = "実際に走らせた exploit"
        closing = f"{_NOT_A_CLAIM}\n\n{_NOT_A_GATE}"
    elif label == DISMISSED:
        header = f"## 🟢 CodeMender の判定: {DISMISSED_PHRASE}（DISMISSED）"
        details_summary = "実際に試みた検証（攻撃は成立しなかった）"
        closing = (
            "> 静的解析が HIGH と報告しても、CodeMender は攻撃を試みて成立しないことを確認しました。"
            "これが **偽陽性の証明** であり、アラート疲れを断つ核心的な価値です。\n\n"
            f"{_NOT_A_GATE}"
        )
    else:
        # Inconclusive: never dress it up as a verdict.
        header = "## ⚪ CodeMender の判定: 不明（UNKNOWN）"
        details_summary = "セッションの出力"
        closing = (
            "> verify がタイムアウトしたか、判定を読み取れませんでした。手動での確認が必要です。\n\n"
            f"{_NOT_A_GATE}"
        )

    parts = [_badge(label), "", header, "", f"**{title}**", "", _FRAMING, "", table, ""]
    if summary:
        parts += [summary, ""]
    if exploit:
        parts += [
            f"<details><summary>{details_summary}</summary>",
            "",
            "```bash",
            exploit,
            "```",
            "",
            "</details>",
            "",
        ]
    parts.append(closing)
    return "\n".join(parts).rstrip() + "\n"


def find_artifact_dir(root: pathlib.Path, finding_id: str | None) -> pathlib.Path | None:
    """Newest session dir under `root` that has an info.yaml, optionally matching id."""
    if not root.exists():
        return None
    sessions = sorted(
        (p for p in root.iterdir() if p.is_dir() and (p / "info.yaml").exists()),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if finding_id:
        for p in sessions:
            info = parse_info((p / "info.yaml").read_text(encoding="utf-8"))
            vid = str(info.get("vulnerability_id", ""))
            if vid and (vid.startswith(finding_id) or finding_id.startswith(vid[:8])):
                return p
        return None
    return sessions[0] if sessions else None


def post_comment(pr: str, body: str, repo: str | None) -> int:
    """Post the comment with `gh pr comment`, reading the body from stdin."""
    cmd = ["gh", "pr", "comment", str(pr), "--body-file", "-"]
    if repo:
        cmd += ["--repo", repo]
    proc = subprocess.run(cmd, input=body, text=True)
    return proc.returncode


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--pr", help="Pull request number to comment on")
    ap.add_argument("--repo", default=None, help="owner/name (defaults to gh's current repo)")
    ap.add_argument("--artifact-dir", default=None, help="Replay this cm verify artifact directory")
    ap.add_argument("--source", choices=["artifacts", "live"], default="artifacts")
    ap.add_argument("--finding-id", default=None, help="Match a live session by finding id")
    ap.add_argument("--print", dest="print_only", action="store_true",
                    help="Print the comment instead of posting (dry run)")
    args = ap.parse_args()

    if args.artifact_dir:
        artifact_dir: pathlib.Path | None = pathlib.Path(args.artifact_dir)
    elif args.source == "live":
        artifact_dir = find_artifact_dir(ARTIFACTS_ROOT, args.finding_id)
    else:
        print("[cm_pr_verdict] --artifact-dir is required when --source is 'artifacts'",
              file=sys.stderr)
        return 2

    if artifact_dir is None or not (artifact_dir / "info.yaml").exists():
        print(f"[cm_pr_verdict] no cm verify artifacts found at: {artifact_dir}", file=sys.stderr)
        return 1

    body = build_comment(artifact_dir)

    if args.print_only:
        print(body)
        return 0
    if not args.pr:
        print("[cm_pr_verdict] --pr is required unless --print is given", file=sys.stderr)
        return 2
    return post_comment(args.pr, body, args.repo)


if __name__ == "__main__":
    raise SystemExit(main())
