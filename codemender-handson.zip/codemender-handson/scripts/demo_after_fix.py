"""パッチが「塞いだ」かつ「壊していない」ことを確かめる（TUTORIAL 4-5）。

Acme の alice で 2 回リクエストする。

  1. 他社（Globex）のファイル -> ブロックされるべき（404）
  2. 自社（Acme）のファイル   -> これまで通り見られるべき（200）

片方だけでは不十分で、両方そろって初めて「直った」と言える。

    uv run --no-sync python scripts/demo_after_fix.py
"""

import pathlib
import sys
import tempfile

# scripts/ から実行されるため、リポジトリのルートを import 対象に加える
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from app import seed
from app.common import db
from app.main import create_app


def main() -> None:
    tmp = pathlib.Path(tempfile.mkdtemp()) / "e.db"
    conn = db.connect(tmp)
    seed.seed(conn)
    conn.close()
    client = create_app(tmp).test_client()
    auth = {"Authorization": f"Bearer {seed.TOKEN_ALICE}"}

    other = client.get(f"/api/attachments/{seed.ATTACHMENT_GLOBEX}", headers=auth)
    blocked = "ブロックされた ✅" if other.status_code == 404 else "★まだ漏れている★"
    print(f"他社のファイル  -> HTTP {other.status_code}  ({blocked})")

    own = client.get(f"/api/attachments/{seed.ATTACHMENT_ACME}", headers=auth)
    intact = "正常に見られる ✅" if own.status_code == 200 else "★機能が壊れた★"
    print(f"自社のファイル  -> HTTP {own.status_code}  ({intact})")


if __name__ == "__main__":
    main()
