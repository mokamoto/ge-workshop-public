#!/usr/bin/env python3
"""bandit の JSON 出力を CodeMender の Simple JSON findings 形式に変換する。

    uv run python scripts/bandit_to_cm.py baseline/bandit.json > baseline/bandit-findings.json
    cm report import -f baseline/bandit-findings.json

CodeMender が受け付ける Simple JSON のフィールド:
    file_path, line, title, message, severity, vuln_type, snippet

★実測（cm 0.5.0）★ `snippet` は **必須で非空**。無い/空だと
`cm report import` が「vulnerable_snippet must be non-empty」で全滅する
（エラーは内部フィールド名 vulnerable_snippet で出るが、入力キーは `snippet`）。
0.2.0 では不要だった。bandit の `code`（該当行の抜粋）をそのまま使う。

Lab 4 で「既存 SAST の検出結果を CodeMender に取り込み、cm verify で
トリアージさせる」導入パターンを示すために使う。
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

# bandit の severity 表記を CodeMender の 4 段階へ写像する。
SEVERITY_MAP = {
    "HIGH": "HIGH",
    "MEDIUM": "MEDIUM",
    "LOW": "LOW",
    "UNDEFINED": "LOW",
}


def convert(bandit_report: dict) -> list[dict]:
    findings = []
    for result in bandit_report.get("results", []):
        cwe = result.get("issue_cwe") or {}
        cwe_id = cwe.get("id")
        vuln_type = f"CWE-{cwe_id}" if cwe_id else result.get("test_id", "UNKNOWN")

        # cm 0.5.0 は snippet が非空であることを要求する。
        # bandit の `code`（行番号付きの該当箇所抜粋）を使い、万一空なら
        # title でフォールバックして「必ず非空」を保証する。
        snippet = (result.get("code") or "").strip() or result["test_name"]

        findings.append(
            {
                "file_path": result["filename"],
                "line": result["line_number"],
                "title": f"[{result['test_id']}] {result['test_name']}",
                "message": (
                    f"{result['issue_text']} "
                    f"(bandit confidence: {result.get('issue_confidence', 'UNKNOWN')})"
                ),
                "severity": SEVERITY_MAP.get(result.get("issue_severity", "LOW"), "LOW"),
                "vuln_type": vuln_type,
                "snippet": snippet,
            }
        )
    return findings


def main() -> int:
    if len(sys.argv) != 2:
        print(f"usage: {sys.argv[0]} <bandit.json>", file=sys.stderr)
        return 2

    report = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    findings = convert(report)
    json.dump(findings, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
    print(f"[bandit_to_cm] converted {len(findings)} findings", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
