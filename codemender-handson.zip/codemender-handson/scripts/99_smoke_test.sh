#!/usr/bin/env bash
#
# 当日朝の疎通確認。
#
# 講師が開催直前に実行し、CodeMender のバックエンドまで到達できることを確認する。
# 1 ファイルだけをスキャンするので、消費トークンとコストは最小。
#
#   ./scripts/99_smoke_test.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
cd "${REPO_ROOT}"

PROJECT_ID="${GOOGLE_CLOUD_PROJECT:-$(gcloud config get-value project 2>/dev/null)}"

echo "===================================================================="
echo "  CodeMender 疎通確認"
echo "===================================================================="
echo "[99_smoke] PROJECT_ID = ${PROJECT_ID}"
echo "[99_smoke] account    = $(gcloud config get-value account 2>/dev/null)"
echo "[99_smoke] cm         = $(command -v cm || echo 'NOT FOUND')"
echo

echo "--- 1. 環境検証 ------------------------------------------------"
cm init --verify
echo

echo "--- 2. 作業ツリーがクリーンか -----------------------------------"
# cm find はスキャン前にワークスペースを VCS reset する。
# 未コミットの変更があると消えるため、ここで止める。
if [[ -n "$(git status --porcelain)" ]]; then
  echo "[99_smoke] ERROR: 未コミットの変更があります。" >&2
  echo "           cm find はスキャン前に 'git checkout HEAD -- . && git clean -fd'" >&2
  echo "           を実行するため、変更が失われます。commit か stash してください。" >&2
  git status --short
  exit 1
fi
echo "[99_smoke] クリーンです"
echo

echo "--- 3. 実スキャン（1 ファイルのみ） -----------------------------"
echo "[99_smoke] cm find app/attachments.py を実行します..."
if cm find app/attachments.py --compact -y; then
  echo
  echo "[99_smoke] スキャン成功"
else
  status=$?
  echo
  echo "[99_smoke] ERROR: スキャンに失敗しました (exit ${status})" >&2
  echo "           よくある原因:" >&2
  echo "             - プロジェクトが CodeMender プレビューの許可リストに入っていない" >&2
  echo "             - ADC の quota project が許可済みプロジェクトになっていない" >&2
  echo "               -> gcloud auth application-default set-quota-project <PROJECT_ID>" >&2
  echo "             - roles/aiplatform.user が付与されていない" >&2
  exit "${status}"
fi
echo

echo "--- 4. 検出結果 --------------------------------------------------"
cm report
echo

echo "--- 5. トークン消費 ----------------------------------------------"
cm stats --since 1h
echo

echo "===================================================================="
echo "  疎通確認 OK。ハンズオンを開始できます。"
echo "===================================================================="
