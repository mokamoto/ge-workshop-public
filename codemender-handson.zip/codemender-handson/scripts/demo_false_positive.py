"""exporter.py の shell=True が悪用できないことを確かめる（TUTORIAL 3-8）。

コマンドインジェクションを狙う文字列を resolve_export_path に渡してみる。
すべて拒否されれば、あの shell=True は誤検知だと自分の目で確認できる。

    uv run --no-sync python scripts/demo_false_positive.py
"""

import pathlib
import sys

# scripts/ から実行されるため、リポジトリのルートを import 対象に加える
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from app.common import storage

PAYLOADS = [
    "'; touch /tmp/pwned; #",
    "$(touch /tmp/pwned)",
    "../../etc/passwd",
]


def main() -> None:
    for bad in PAYLOADS:
        try:
            storage.resolve_export_path(bad, "csv")
            print(f"通ってしまった: {bad}")
        except storage.UnsafeExportRequest:
            print(f"拒否された    : {bad}")


if __name__ == "__main__":
    main()
