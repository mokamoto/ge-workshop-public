#!/usr/bin/env bash
#
# cm report --format html の HTML レポートをブラウザで開けるようにする。
#
# Cloud Shell にはブラウザが無いため `cm report -f html -o`（--open）は使えない。
# 代わりに簡易 HTTP サーバを立て、Cloud Shell の「ウェブでプレビュー」で開く。
#
#   make report        起動して URL を表示
#   make report-stop   止める
#
# ポートは PORT で変えられる（ウェブプレビューは 8080〜8089 のみ）。
set -euo pipefail

PORT="${PORT:-8080}"
SRC="${HOME}/.codemender/reports/report.html"
SERVE_DIR="${HOME}/.codemender/reports/serve"

# Cloud Shell では cm を $HOME/bin に入れる。新しいタブだと PATH に無いことがある。
if ! command -v cm >/dev/null 2>&1 && [[ -x "${HOME}/bin/cm" ]]; then
  export PATH="${HOME}/bin:${PATH}"
fi

if ! command -v cm >/dev/null 2>&1; then
  echo "[report] ✗ cm が見つかりません。次を実行してから再試行してください:" >&2
  echo '[report]   export PATH="${HOME}/bin:${PATH}"' >&2
  exit 1
fi

echo "[report] HTML を生成しています..."
# ログ行が混ざると読みにくいので、失敗したときだけ出す。
if ! out="$(cm report --format html 2>&1)"; then
  echo "${out}" >&2
  exit 1
fi

if [[ ! -f "${SRC}" ]]; then
  echo "[report] ✗ ${SRC} がありません。" >&2
  echo "[report]   先に cm find でスキャンしてください。" >&2
  exit 1
fi

# ウェブプレビューはディレクトリのルートを開くので、index.html として置く。
mkdir -p "${SERVE_DIR}"
cp "${SRC}" "${SERVE_DIR}/index.html"

# 前回のサーバが残っていたら止める（何度でも実行できるように）。
pkill -f "http\.server ${PORT}" 2>/dev/null || true
sleep 0.5

nohup python3 -m http.server "${PORT}" --directory "${SERVE_DIR}" \
  >/tmp/cm-report-server.log 2>&1 &
sleep 1

if ! curl -sf -o /dev/null "http://localhost:${PORT}/"; then
  echo "[report] ✗ サーバが起動しませんでした。/tmp/cm-report-server.log を見てください。" >&2
  exit 1
fi

echo
if command -v cloudshell >/dev/null 2>&1; then
  echo "[report] ブラウザで開いてください:"
  echo
  echo "    $(cloudshell get-web-preview-url -p "${PORT}")"
  echo
  echo "[report] 画面右上の「ウェブでプレビュー」→「ポート ${PORT} でプレビュー」でも同じです。"
else
  echo "[report] ブラウザで開いてください:  http://localhost:${PORT}/"
fi
echo "[report] 止めるときは: make report-stop"
