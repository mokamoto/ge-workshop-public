#!/usr/bin/env bash
#
# 既存 SAST（bandit / semgrep）のベースラインを生成する。
# Lab 1 の比較教材、および Lab 4 の import 教材になる。
#
# 生成物:
#   baseline/bandit.json           … bandit の生出力
#   baseline/bandit-findings.json  … CodeMender の Simple JSON 形式
#   baseline/semgrep.sarif         … SARIF 形式
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
cd "${REPO_ROOT}"

mkdir -p baseline

echo "[05_baseline] bandit を実行します（オフラインで動作）"
uv run --no-sync bandit -r app/ -f json -q -o baseline/bandit.json 2>/dev/null || true
uv run --no-sync python scripts/bandit_to_cm.py baseline/bandit.json \
  > baseline/bandit-findings.json

# semgrep は既定の依存に含めていない（Dependabot アラートとディスク削減のため）。
# 同梱の baseline/semgrep.sarif で足りるので、未導入ならスキップする。
echo "[05_baseline] semgrep を uvx で一時実行します（初回はダウンロードに数分かかります）"
if uvx semgrep \
     --config=p/python \
     --config=p/security-audit \
     --config=p/owasp-top-ten \
     --config=p/flask \
     --sarif --output=baseline/semgrep.sarif \
     --metrics=off app/ >/dev/null 2>&1; then
  echo "[05_baseline] semgrep OK"
else
  echo "[05_baseline] WARN: semgrep に失敗しました（リポジトリ同梱の結果をそのまま使います）"
fi

echo "[05_baseline] 生成物:"
ls -la baseline/
echo
echo "[05_baseline] 比較の解説は baseline/README.md を参照してください。"
