# GitHub CodeQL — スナップショット（2026-08-27）

`cloud-gtm/codemender-handson`（教材開発用の内部リポジトリ）で GitHub Advanced Security
を有効化した直後、CodeQL のデフォルトセットアップが自動で走って出た結果。
**`cm` の実行結果ではない。** GitHub 純正のスキャナ。

DEMO_SCRIPT.md の「GitHub 純正の Code Scanning でも同じ」デモが、
ネットワークや権限の都合でライブで開けないときのフォールバック。
`gh api repos/cloud-gtm/codemender-handson/code-scanning/alerts` で再取得できる。

## 結果

| # | ルール | 重大度 | ファイル | 行 | 内容 |
|---|---|---|---|---|---|
| 4 | `py/full-ssrf` | **CRITICAL** | `app/webhook.py` | 34 | The full URL of this request depends on a user-provided value |
| 3 | `py/sql-injection` | HIGH | `app/reports.py` | 90 | This SQL query depends on a user-provided value |
| 2 | `py/stack-trace-exposure` | MEDIUM | `app/exporter.py` | 50 | Stack trace information flows to this location and may be exposed to an external user |
| 1 | `actions/missing-workflow-permissions` | MEDIUM | `.github/workflows/ci.yml` | 15 | Workflow does not limit the permissions of the `GITHUB_TOKEN` |

**`app/attachments.py` は 0 件。** テナント越境 IDOR（V2）は検出されていない。

## V1〜V4 との対応

| 教材の欠陥 | CodeQL の検出 |
|---|---|
| V1 SQLi (`reports.py`) | ✅ 検出（Alert #3、HIGH） |
| **V2 テナント越境 IDOR (`attachments.py`)** | ❌ **未検出** |
| V3 偽陽性（`exporter.py` の `shell=True`、bandit が HIGH/HIGH） | 検出せず。**同じファイルの別箇所**（stack-trace-exposure）を Alert #2 で指摘している。V3 そのものではない |
| V4 SSRF (`webhook.py`) | ✅ 検出（Alert #4、CRITICAL） |

Alert #1 は `app/` ではなく `ci.yml`（ワークフローの権限設定）に対するもので、
本教材の題材アプリとは無関係。CodeQL が Actions の言語もスキャンしている例として言及可。

## 注意

- **push のたびに再スキャンされる。** このスナップショットは 2026-08-27 時点のもの。
  当日は事前に一度ライブで確認してから臨むこと
- GHAS が有効なこと（この結果が出ていること）と、**`codemender-scan.yml` が CodeMender
  の結果をこの Code Scanning に送れることは別レイヤー。** 後者もこのリポジトリでは
  実際の PR で通しで動くことを確認済み（2026-08-31、RUNBOOK.md §6.5）。PR 単位の
  アラートなので、確認するときは `?ref=refs/pull/<N>/merge` を付けて API を叩くこと
