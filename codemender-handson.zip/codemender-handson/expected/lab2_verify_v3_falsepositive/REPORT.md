# Title: False Positive - subprocess_popen_with_shell_equals_true in exporter.py

## Executive Summary
A static analysis tool (Bandit) identified a high-severity finding (`[B602] subprocess_popen_with_shell_equals_true`) in `app/exporter.py` on line 62 due to the use of `subprocess.run(..., shell=True)`.
However, detailed source code analysis and runtime behavior verification confirm that this is a **False Positive**. The parameters passed to the subprocess call are fully controlled and constructed by the server using highly restricted formats (UUID4 hex and hardcoded values), ensuring that no user-controlled input or shell metacharacters can ever reach the command invocation.

## Root Cause Analysis (RCA)
The vulnerability is flagged in `/private/tmp/cm-clean/app/exporter.py` around line 59–65:

```python
    # LibreOffice で PDF に変換する。
    # csv_path は EXPORT_ROOT / "<uuid4 hex>.csv" の形しか取り得ない。
    command = f"soffice --headless --convert-to pdf --outdir {csv_path.parent} {csv_path}"
    result = subprocess.run(
        command,
        shell=True,
        capture_output=True,
        timeout=SOFFICE_TIMEOUT_SECONDS,
    )
```

For a command injection to be possible here, the value of `csv_path` or `csv_path.parent` must contain user-controlled shell metacharacters. Let's analyze how `csv_path` is resolved in `app/common/storage.py`:

```python
EXPORT_ROOT = Path("/tmp/cm-workshop/exports")

# 出力を許可する拡張子。ここにない値は一切受け付けない。
ALLOWED_EXTENSIONS = frozenset({"csv", "pdf", "xlsx"})

# レポート ID は UUID 形式でなければならない。
_UUID_RE = re.compile(r"\A[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\Z")

def resolve_export_path(report_id: str, extension: str) -> Path:
    if not _UUID_RE.match(report_id):
        raise UnsafeExportRequest(f"report_id must be a UUID: {report_id!r}")

    normalized_ext = extension.lower().lstrip(".")
    if normalized_ext not in ALLOWED_EXTENSIONS:
        raise UnsafeExportRequest(f"extension not allowed: {extension!r}")

    EXPORT_ROOT.mkdir(parents=True, exist_ok=True)

    # ファイル名はユーザー入力から完全に独立している。
    server_generated_name = uuid.uuid4().hex
    return EXPORT_ROOT / f"{server_generated_name}.{normalized_ext}"
```

### Flow of Variables:
1. `csv_path.parent` is always `EXPORT_ROOT`, which is hardcoded to `/tmp/cm-workshop/exports`.
2. `server_generated_name` is generated purely on the server using `uuid.uuid4().hex`, which contains only alphanumeric characters (`[0-9a-f]`) and has a fixed length of 32 characters.
3. `normalized_ext` is hardcoded as `"csv"` when called from `app/exporter.py` (`storage.resolve_export_path(report_id, "csv")`), or is validated against `ALLOWED_EXTENSIONS` (`csv`, `pdf`, `xlsx`).
4. While `report_id` is a user-controlled parameter, it is only validated using regex (`_UUID_RE`) and is **never** concatenated, interpolated, or used in the returned file path or the final shell command.

Because of this rigid sanitization and the complete detachment of user input from the file path, the final shell command constructed is completely safe:
```bash
soffice --headless --convert-to pdf --outdir /tmp/cm-workshop/exports /tmp/cm-workshop/exports/<random_32_hex_chars>.csv
```

No shell metacharacters, parameter injection, or command chaining is possible.

## Fix Recommendation
Although the code is secure against command injection, the use of `shell=True` is generally discouraged. To satisfy static analyzers and reduce the potential attack surface further, the `subprocess.run` call should be refactored to pass arguments as a list and disable the shell interpolation:

```python
    command = [
        "soffice",
        "--headless",
        "--convert-to",
        "pdf",
        "--outdir",
        str(csv_path.parent),
        str(csv_path),
    ]
    result = subprocess.run(
        command,
        shell=False,
        capture_output=True,
        timeout=SOFFICE_TIMEOUT_SECONDS,
    )
```

## Exploitation & Reproduction
Since this is a verified **False Positive**, no working exploit could be constructed. Any attempt to supply a malicious `report_id` (e.g., `; touch /tmp/pwned;`) is caught early in the validation layer and rejected with a `400 Bad Request` or `404 Not Found` response.

The unit tests included in the codebase (specifically in `tests/test_exporter.py`) confirm that the application correctly rejects malicious inputs and only processes safe, server-generated names.
