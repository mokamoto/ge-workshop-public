# 実際の実行記録

## 状態: 収集済み（2026-08-10 / cm 0.2.0 / `gemini-3.5-flash`）

> これらは収録当時の出力（0.2.0 / 3.5）。当日のライブ実行は cm 0.11.0 / `gemini-3.8-flash`
> （`cm find --deep`）で行うが、中核の検出結果・判定・IDOR のパッチ内容は一致することを
> 2026-10-05 に再確認済み（0.7.0 は 2026-09-14、0.5.0 は 2026-09-02）。
> 違いは 2 点: deep スキャンは `http_client.py` の DNS リバインディングも報告する
> （`lab1_find_app.txt` には無い）。exploit の手段は回によって変わる
> （`lab2_verify_v2` はポート 5599 で Flask を起動。0.7.0 はテストクライアント、0.11.0 は空きポート）。

このディレクトリには、実機で `cm` を実行したときの**本物の出力**が入っている。

3 つの用途がある。

1. **教材から直接読ませる** — Step 3-6（`lab2_verify_v2/REPORT.md`）、
   Step 4-7（`lab3_fix_v4_nocontext.diff`）は、ライブ実行せずここを読む
2. **30 分版のエグゼクティブデモ** — `DEMO_SCRIPT.md` の短縮版はライブ実行を一切せず、
   すべてここの記録を投影して進める
3. **縮退運用** — プレビュー許可が間に合わなかったときに、これを見せて議論だけ回す

## 中身

| ファイル | 何の記録か | 使う場面 |
|---|---|---|
| `lab1_find_app.txt` | `cm find app/` の全出力。V1 / V2 / V4 を検出、**V3 は報告なし** | 30 分版 (4) |
| `lab2_verify_v2/` | **★最重要★** IDOR の verify。`session.txt` に `EXPLOIT SUCCESSFUL` が入っている | TUTORIAL 3-6 / 30 分版 (6)(7) |
| `lab2_verify_v3_falsepositive/` | 偽陽性の verify。`info.yaml` が `status: invalid` / `confidence: certain` | 30 分版 (8) |
| `lab3_fix_v1_sqli.{diff,txt}` | SQLi の修正。`ORDER BY` は許可リスト方式にしている | 質問されたとき |
| `lab3_fix_v2.diff` + `lab3_fix_v2_session.txt` | IDOR の 3 行パッチ | 30 分版 (9) |
| **`lab3_fix_v4_nocontext.{diff,txt}`** | **SSRF の修正。規約を一切渡していないのに `fetch_external` を採用した**。テストファイルも書き換わっている | **TUTORIAL 4-7（読み合わせ）** |
| `lab90_find_native.txt` / `lab90_verify_v5*` / `lab90_fix_v5.*` | C / ASAN のボーナス一式 | ボーナス |
| `codeql_alerts.md` | **`cm` ではなく GitHub 純正の CodeQL の結果。** GHAS 有効化直後のスナップショット | DEMO_SCRIPT.md「GitHub 純正の Code Scanning でも同じ」のフォールバック |

各 `*_verify_*/` ディレクトリの中身は CodeMender が生成した成果物そのもの。

| ファイル | 中身 |
|---|---|
| `PLAN.md` | エージェントが立てた検証計画 |
| `exploit.sh` | **実際に実行された攻撃コード** |
| `REPORT.md` | 生成された報告書（英語） |
| `LOG.md` | ステップごとの実行ログ |
| `info.yaml` | 判定結果（`status` / `confidence` / `tags`） |

## 再取得するとき

`RUNBOOK.md` の「通し実行のチェックリスト」に沿って実行し、上書きする。

```bash
cm find app/ --compact --model gemini-3.7-flash 2>&1 | tee /tmp/find.txt
cm verify <ID> --model gemini-3.7-flash 2>&1 | tee /tmp/verify.txt
cm fix <ID> --model gemini-3.7-flash && cm vcs diff > /tmp/fix.diff
```

> **★リポジトリ内に直接リダイレクトしないこと★**
> `cm find` / `verify` / `fix` は開始時に `git checkout HEAD -- . && git clean -fd` 相当を走らせる。
> **実行中に消される。** 必ず `/tmp` に書いてからコピーする。

`~/.codemender/artifacts/<session>/` に `PLAN.md` / `exploit.sh` / `REPORT.md` /
`LOG.md` / `info.yaml` が出るので、ディレクトリごとコピーする。
**ファイル名は大文字**（公式資料には小文字で載っているが実機は大文字）。

## パスの表記について

ログとスクリプトには、収集時の実行環境の絶対パスがそのまま残っている。
**あえて書き換えていない。** 実際の実行記録であり、書き換えると証跡としての意味が失われるため。

**受講者用の配布 ZIP では `scripts/build_zip.sh` が `<user>` に匿名化する。**
リポジトリ側では素のまま保持する。

## 注意

**受講者の結果がこれと一致する保証はない。** LLM エージェントなので実行ごとに変わる。
教材から参照するときは「あなたの環境の結果に読み替えてください」を添えること。

再現性の観測値（3〜4 回試行）は `RUNBOOK.md` §2 の実測記録にある。
本物 3 件は毎回検出され、偽陽性 V3 は毎回報告されなかった。
