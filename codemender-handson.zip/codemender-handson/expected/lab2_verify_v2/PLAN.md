# Plan for Verifying Broken Object-Level Authorization (IDOR) / Tenant Bypass in Attachment Download

- [x] Inspect `app/attachments.py` to analyze the vulnerability.
- [x] Inspect `app/seed.py` to identify the seed tokens and attachment IDs.
- [x] Create a detailed execution plan and log the analysis.
- [x] Develop a standalone script `exploit.sh` in `.exploit/` that queries the attachment of the other tenant using Alice's credentials.
- [x] Verify that the exploit returns the unauthorized attachment metadata/content.
- [x] Write pytest `tests/test_attachment_idor.py` to ensure it is reproduced via pytest suite and verify its execution.
- [x] Fill out `LOG.md`, `REPORT.md`, `info.yaml`, and call `report_finding` and `finish`.
