# はじめに — ZIP から始める場合

このワークショップは **git があることを前提**にしている。
ZIP には `.git` が含まれていないので、**展開したら必ず次を実行すること。**

```bash
cd ~/codemender-handson
export GOOGLE_CLOUD_PROJECT="<許可を受けたプロジェクトID>"
gcloud config set project "${GOOGLE_CLOUD_PROJECT}"
./scripts/setup.sh
```

`setup.sh` が `git init` と初回コミットまで面倒を見る
（プロジェクトが未設定だと最初に止まるので、先に `gcloud config set project` を通すこと）。

> **なぜ git が要るのか**
>
> - `cm find` / `verify` / `fix` は開始時にワークスペースを VCS reset する
> - `cm vcs diff` で生成されたパッチをレビューする（Lab 3 の中心）
> - `cm vcs reset --force` で何度でもやり直せる
>
> `git init` を忘れると **Lab 3 が成立しない。**

## Cloud Shell への持ち込み方

1. Cloud Shell を開く
2. 右上の **⋮ → Upload** でこの ZIP をアップロード
3. 展開してセットアップ

```bash
cd ~
unzip -q codemender-handson.zip
cd codemender-handson
export GOOGLE_CLOUD_PROJECT="<許可を受けたプロジェクトID>"
gcloud config set project "${GOOGLE_CLOUD_PROJECT}"
./scripts/setup.sh
./scripts/99_smoke_test.sh
```

**事前に空き容量を確認すること。** 教材一式で約 390MB 使う。

```bash
df -h $HOME      # 空きが 1GB を切っていたら整理する
```

次は [`TUTORIAL.md`](TUTORIAL.md) へ。**これ 1 本で最後まで進められます。**

## 最後の 20 分について

手を動かすのは約 2 時間 40 分で、**最後の 20 分は議論の時間**です。
「御社のどこに効くか」「最初に何を試すか」を一緒に決めます。

使うのは [`WORKSHEET.md`](WORKSHEET.md) です。事前に埋める必要はありません。
