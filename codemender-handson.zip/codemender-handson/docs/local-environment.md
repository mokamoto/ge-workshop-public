# 付録: ローカル環境での実行

Cloud Shell ではなく手元の PC で実施する場合の手順と注意点。

> **⚠️ 先に読むこと**
> CodeMender の CLI は、エージェントの指示で**ホスト上でシェルコマンドを実行し、
> ファイルを書き換える**。サンドボックスは**既定で無効**である。
> 公式ドキュメントは「組み込みのプロセスレベルサンドボックスを有効にするか、
> 隔離された VM / コンテナで実行することを強く推奨」としている。
>
> 手元の PC で動かす場合は、**必ず `--sandbox` を付けるか、
> `~/.codemender/config.yaml` で `sandbox.enabled: true` にする**こと。

---

## 1. CLI の導入

`scripts/01_install_cm.sh` が OS とアーキテクチャを判別して処理するので、
基本はそのまま使える。

```bash
./scripts/01_install_cm.sh
```

手動で入れる場合のアーティファクト名。

| 環境 | アーティファクト |
|---|---|
| Linux x86_64 | `cm-linux-amd64.zip` |
| Linux ARM64 | `cm-linux-arm64.zip` |
| macOS Intel | `cm-darwin-amd64.zip` |
| macOS Apple Silicon | `cm-darwin-arm64.zip` |
| Windows x86_64 | `cm-windows-amd64.zip` |
| Windows ARM64 | `cm-windows-arm64.zip` |

```bash
gcloud artifacts generic download \
  --project=cmoc-prod \
  --location=us \
  --repository=codemender-cli-production \
  --package=cm \
  --version=stable \
  --name=cm-darwin-arm64.zip \
  --destination=./

unzip cm-darwin-arm64.zip
chmod +x cm
mv cm /usr/local/bin/cm     # ローカルなら /usr/local/bin で永続する
```

更新は `cm update`（システム全体に入れた場合は `sudo cm update`）。

---

## 2. サンドボックスを有効にする

```yaml
# ~/.codemender/config.yaml
sandbox:
  enabled: true
  mounts:
    target_dir: "."
  network:
    profile: "permissive-closed"
```

またはコマンドごとに指定する。

```bash
cm find app/ --sandbox
cm verify <ID> --sandbox
```

`--unrestricted` はこの保護を**外す**フラグである。意味を理解せずに使わない。

---

## 3. 前提ツール

| ツール | 用途 | 無い場合 |
|---|---|---|
| `gcloud` | CLI の取得と認証 | 必須 |
| `git` | `cm vcs` の各コマンド | 必須 |
| `uv` | Python の依存管理 | `04_bootstrap_app.sh` が自動導入 |
| C コンパイラ（clang / gcc） | ボーナスラボ | 無ければボーナスをスキップ |

macOS では Xcode Command Line Tools（`xcode-select --install`）で clang が入る。
ASAN もそのまま使える。

---

## 4. ローカル特有の落とし穴

### 4-1. 社給端末で `uv sync` が 401 で失敗する

企業が管理する `/etc/uv/uv.toml` などで、既定の package index が
社内リポジトリに向いていることがある。

```
hint: An index URL (https://us-python.pkg.dev/.../simple/) could not be
queried due to a lack of valid authentication credentials (401 Unauthorized)
```

PyPI にフォールバックする。

```bash
UV_DEFAULT_INDEX=https://pypi.org/simple uv sync
```

`scripts/04_bootstrap_app.sh` はこのフォールバックを自動で行う。

### 4-2. ADC の quota project が別プロジェクトを向いている

`gcloud config set project` を変えても ADC の `quota_project_id` は追随しない。
CodeMender はこちらを見る。

```bash
gcloud auth application-default set-quota-project <PROJECT_ID>
export GOOGLE_CLOUD_PROJECT=<PROJECT_ID>
```

確認方法。

```bash
python3 -c "
import json
d = json.load(open('$HOME/.config/gcloud/application_default_credentials.json'))
print('quota_project_id =', d.get('quota_project_id'))
"
```

### 4-3. `cm find` が作業中の変更を消す

`vcs.type: git` を設定していると、`cm find` はスキャン前に
`git checkout HEAD -- . && git clean -fd` 相当を実行する。
**未コミットの変更もアントラックのファイルも消える。**

スキャン前に必ず確認する。

```bash
git status --short      # 何も出ないこと
```

### 4-4. `/tmp` のパーミッション

教材アプリは `/tmp/cm-workshop/` に SQLite とエクスポート成果物を作る。
共用マシンで衝突する場合は `app/common/db.py` の `DEFAULT_DB_PATH` と
`app/common/storage.py` の `EXPORT_ROOT` を変更する。

---

## 5. 隔離環境で動かしたい場合

Docker が使えるなら、コンテナ内で動かすのが最も安全である。

```dockerfile
# 例（このリポジトリには同梱していない）
FROM python:3.12-slim
RUN apt-get update && apt-get install -y git make clang curl unzip
COPY . /workspace
WORKDIR /workspace
```

ADC はホストからマウントする。

```bash
docker run -it --rm \
  -v "$PWD":/workspace \
  -v "$HOME/.config/gcloud":/root/.config/gcloud:ro \
  -e GOOGLE_CLOUD_PROJECT \
  codemender-handson bash
```

ただし**ハンズオンの標準は Cloud Shell** である。
参加者ごとの環境差分に時間を取られないことを優先する。

---

戻る: [TUTORIAL.md](../TUTORIAL.md)
