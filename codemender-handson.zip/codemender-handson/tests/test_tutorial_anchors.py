"""TUTORIAL.md のコマンドが指すコードが存在し続けることを保証する。

チュートリアルはコードから断片を抜き出して見せる。アンカー（関数名や
特徴的な文字列）が変わると、参加者の画面に何も表示されず詰まる。
教材アプリを編集したときにここで気づけるようにしておく。
"""

from __future__ import annotations

import pathlib
import re
import unicodedata

import pytest

REPO = pathlib.Path(__file__).resolve().parent.parent
TUTORIAL = REPO / "TUTORIAL.md"
MAKEFILE = REPO / "Makefile"

# TUTORIAL 内で参照しているコードのアンカー → 存在すべきファイル
ANCHORS = [
    ("def download_attachment", "app/attachments.py"),
    (").fetchone()", "app/attachments.py"),
    ("SELECT id, tenant_id, author_id", "app/reports.py"),
    ("AND tenant_id = ?", "app/reports.py"),
    ("soffice --headless", "app/exporter.py"),
    ("def resolve_export_path", "app/common/storage.py"),
    ("return EXPORT_ROOT", "app/common/storage.py"),
    ("社内規約", "app/common/http_client.py"),
    ("def test_owner_can_download_own_attachment", "tests/test_attachments.py"),
]


@pytest.mark.parametrize("anchor,rel", ANCHORS)
def test_tutorial_anchor_still_exists(anchor: str, rel: str) -> None:
    """TUTORIAL.md が抜き出そうとしている箇所がコードに残っていること。"""
    text = (REPO / rel).read_text(encoding="utf-8")
    assert anchor in text, (
        f"{rel} から '{anchor}' が消えています。"
        f" TUTORIAL.md の該当コマンドが空を返すので、両方を直してください。"
    )


def test_tutorial_has_no_line_number_extraction() -> None:
    """行番号でコードを抜き出していないこと。

    `sed -n '19,36p'` のような指定はコードを 1 行足すだけでずれる。
    アンカー指定（関数名など）を使うこと。
    """
    text = TUTORIAL.read_text(encoding="utf-8") + MAKEFILE.read_text(encoding="utf-8")
    bad = re.findall(r"sed -n '\d+,\d+p'", text)
    assert not bad, f"行番号指定が残っています: {bad}"


def test_tutorial_images_exist() -> None:
    """埋め込んだ画像が実在すること。"""
    text = TUTORIAL.read_text(encoding="utf-8")
    missing = [
        m for m in re.findall(r"!\[[^\]]*\]\(([^)]+)\)", text)
        if not (REPO / m).exists()
    ]
    assert not missing, f"画像が見つかりません: {missing}"


def test_tutorial_make_targets_exist() -> None:
    """TUTORIAL が呼ぶ make ターゲットが Makefile に定義されていること。

    狭い teachme パネルでも貼り付けが壊れないよう、長いコマンドは
    Makefile 側に置いている。呼び出し側と定義がずれると詰まる。
    """
    used = set(re.findall(r"^make ([a-z-]+)$", TUTORIAL.read_text(encoding="utf-8"), re.M))
    defined = set(re.findall(r"^([a-z-]+):", MAKEFILE.read_text(encoding="utf-8"), re.M))
    missing = sorted(used - defined)
    assert not missing, f"Makefile に無いターゲットを呼んでいます: {missing}"


def test_tutorial_commands_survive_narrow_terminal() -> None:
    r"""bash ブロックに、折り返すと壊れる行が無いこと。

    Cloud Shell の teachme パネルを開くとターミナルが 40 桁前後になり、
    長い行は `\` + 改行で折り返されて貼り付けられる。
    シェルのコマンドは行継続として解釈されるので無害だが、

      * 末尾コメント付きの長い行 … 折り返した後半がコマンド扱いになる
      * ヒアドキュメント内の Python … `\` が継続にならず構文エラーになる

    この 2 つは実際に受講者の手を止めた。
    """
    text = TUTORIAL.read_text(encoding="utf-8")

    heredocs = re.findall(r"<<'?[A-Z]+'?", text)
    assert not heredocs, (
        f"ヒアドキュメントが復活しています: {heredocs}。"
        " scripts/ にファイルとして置き、make 経由で呼んでください。"
    )

    def width(s: str) -> int:
        return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in s)

    bad = []
    in_block = False
    for i, line in enumerate(text.splitlines(), 1):
        if line.startswith("```bash"):
            in_block = True
            continue
        if line.startswith("```"):
            in_block = False
            continue
        if in_block and "#" in line and not line.lstrip().startswith("#"):
            if width(line) > 46:
                bad.append((i, line))
    assert not bad, (
        "末尾コメント付きの長い行があります。コメントを 1 行上へ移してください:\n"
        + "\n".join(f"  L{i}: {s}" for i, s in bad)
    )
