"""bandit_to_cm.py の変換を検証する。"""

from __future__ import annotations

import pathlib
import sys

REPO = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "scripts"))

import bandit_to_cm  # noqa: E402

SAMPLE = {
    "results": [
        {
            "filename": "app/common/storage.py",
            "line_number": 19,
            "test_id": "B108",
            "test_name": "hardcoded_tmp_directory",
            "issue_text": "Probable insecure usage of temp file/directory.",
            "issue_confidence": "MEDIUM",
            "issue_severity": "MEDIUM",
            "issue_cwe": {"id": 377},
            "code": '18 \n19 EXPORT_ROOT = Path("/tmp/x")\n20',
        },
        {  # code 欠落時のフォールバックを確認
            "filename": "app/seed.py",
            "line_number": 24,
            "test_id": "B105",
            "test_name": "hardcoded_password_string",
            "issue_text": "Possible hardcoded password.",
            "issue_confidence": "MEDIUM",
            "issue_severity": "LOW",
            "issue_cwe": {"id": 259},
            "code": "",
        },
    ]
}


def test_every_finding_has_a_nonempty_snippet():
    """★回帰ガード★ cm 0.5.0 は `snippet` 必須。空だと import が全滅する。

    キー名は `snippet`（cm 内部フィールドは vulnerable_snippet だが入力キーは snippet）。
    """
    findings = bandit_to_cm.convert(SAMPLE)
    assert len(findings) == 2
    for f in findings:
        assert "snippet" in f, "入力キーは 'snippet' でなければ cm 0.5.0 が読まない"
        assert f["snippet"].strip(), "snippet は非空でなければならない"
    # code があればそれを使う
    assert "EXPORT_ROOT" in findings[0]["snippet"]
    # code が空なら test_name にフォールバック
    assert findings[1]["snippet"] == "hardcoded_password_string"


def test_keeps_the_documented_simple_json_fields():
    f = bandit_to_cm.convert(SAMPLE)[0]
    assert set(f) >= {"file_path", "line", "title", "message", "severity", "vuln_type", "snippet"}
    assert f["file_path"] == "app/common/storage.py"
    assert f["vuln_type"] == "CWE-377"
