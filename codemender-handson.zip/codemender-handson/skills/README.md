# Driving CodeMender from a coding agent

`cm` is a CLI, so a coding agent can run it. Give the agent one skill definition and
**"security review this repository"** becomes a single instruction that runs
scan → prove exploitability → patch → open a PR.

[`codemender/SKILL.md`](codemender/SKILL.md) is that definition.

> **This is the cheap version of a management console.** Customers who see the workshop
> often ask for a web UI that kicks off scans and shows everything. You can build one —
> but the hard parts are isolation, async jobs and state, not the UI, and Pre-GA terms
> limit use to "testing and evaluation". A skill file gets you the same *workflow* today,
> in the editor the developer is already in. Show this before offering to build a portal.
>
> It is **demoed in the closing discussion, not run as a lab step** — see
> [`../DISCUSSION.md`](../DISCUSSION.md) §4.

## It is already wired up in this repository

`skills/codemender/` is the single source of truth. The agent directories are
**symlinks** to it, so opening this repo activates the skill with no copying:

```
.claude/skills/codemender  ->  ../../skills/codemender     # Claude Code
.agents/skills/codemender  ->  ../../skills/codemender     # Antigravity (per internal Lab 1)
```

`tests/test_skill_install.py` fails if either becomes a real copy, because copies drift.
**They already did once:** the version installed under `~/.claude/skills/` had gained the
`FilePath`-basename pitfall while the repository copy had not.

> The `.agents/skills/` path follows what internal Lab 1 uses for Antigravity.
> **Verify it against your own Antigravity version** — see the caveat below; these
> locations move between releases.

## Get the division of labour right

This matters more than the tooling.

| | Owner |
|---|---|
| **Deciding whether a finding is exploitable** | **CodeMender** — it writes and runs a real exploit. Nothing else here can do that |
| Choosing which findings are worth verifying | The agent |
| Branching, commits, PR narrative | The agent |
| Accepting or rejecting the diff | **A human** |

Having CodeMender write your PR description adds nothing. Having the agent *guess* at
exploitability turns the whole thing back into static analysis.

## Using it in another repository

Inside *this* repo nothing is needed — the symlinks above already do it. To use the
skill on a customer's project, or across all your projects, you have to place it there.

The skill file itself is portable — the `name` / `description` front matter format is
the same across agents. **Where it goes is not.** Every agent looks in its own place,
and those locations change between versions, so check your agent's own documentation
rather than trusting the paths below.

At the time of writing:

```bash
# Claude Code — user-level (available in every project)
cp -r skills/codemender ~/.claude/skills/

# Claude Code — project-level, checked into that repo
mkdir -p <other-repo>/.claude/skills && cp -r skills/codemender <other-repo>/.claude/skills/

# Antigravity — user-level
cp -r skills/codemender ~/.gemini/antigravity/skills/
```

> **Prefer the registration trick below over copying.** Every copy is a future
> inconsistency; see the drift that already happened, noted at the top of this file.

### Keeping one copy instead of several

Some agents let you register an extra directory rather than copying the file around.
Antigravity, for example, reads the directories listed in `~/.gemini/config/skills.json`:

```json
{
  "entries": [
    { "path": "/Users/you/.claude/skills" }
  ]
}
```

With that in place, Antigravity picks up skills installed for Claude Code, and one file
serves both. **This is a configuration you choose to make — it is not a default**, and
the mechanism differs per agent.

### Check that it worked

```bash
agy -p "What can the codemender skill do?"
```

The agent will ask permission to read the file the first time. Approve it.

## Before you run it

These are measured behaviours, not theory. An integration written without them will
break.

### 1. Uncommitted work gets deleted

`cm find`, `cm verify` and `cm fix` each begin by resetting the workspace:

```
git checkout HEAD -- . && git clean -fd
```

`git clean -fd` removes **untracked files**, not just edits. Anything the agent was
part-way through writing is gone. This destroyed work three times while this workshop
was being built.

The skill therefore requires a clean tree before calling `cm`, and writes all output to
`/tmp` — never into the repository.

### 2. `-y` alone will not run non-interactively

`-y` covers per-command and per-write confirmations. It does **not** cover the
responsibility warning, which demands a real TTY. From an agent you get:

```
responsibility warning: warning not acknowledged
```

`--bypass-warning` is required. Note what that means: you are pre-accepting *"the agent
may modify files and execute commands on your system."* Say so out loud rather than
burying it in a flag.

### 3. `cm verify` can approach the command timeout

Measured at roughly 5–8 minutes, occasionally near 10. Agents commonly cap a
single command at around 10 minutes, so a run can hit it. Run verification in the
background and poll for it.

### 4. Pin the model

```
--model gemini-3.8-flash
```

Measured on cm 0.11.0 (its default model is `gemini-3.8-flash`):

| Model | Result |
|---|---|
| **`gemini-3.8-flash`** (cm 0.11.0 default) | `--deep`: 3 core findings, 100% confidence, plus an HTTP-helper DNS-rebinding finding |
| `gemini-3.7-flash` | `--deep`: same core findings, but also flags CSV formula injection in the exporter |
| `gemini-3.6-flash` | 3 findings, 100% confidence (quick scan, 0.5.0) |
| `gemini-3.5-flash` | 3 findings, 100% confidence (quick scan, 0.5.0) |

## What not to do

**Do not make this a required merge check.**

CodeMender is Pre-GA and its terms limit use to testing and evaluation. Beyond the
terms, a check that takes several minutes and returns slightly different results each run
has no business blocking a merge.

Ad-hoc runs, reviewed by a person, are the shape that works today.
