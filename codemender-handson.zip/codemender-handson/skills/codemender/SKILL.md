---
name: codemender
description: Find, prove, and fix security vulnerabilities with the CodeMender CLI (`cm`), then open a PR. Use when the user asks to "scan for vulnerabilities", "security review this repo", "check if this is exploitable", "prove this bug is real", "fix this vulnerability", "codemender", "cm find/verify/fix" — or when a security finding needs its exploitability established rather than guessed at. Do NOT use for general code review or linting.
---

# CodeMender (`cm`)

An agentic security tool. Unlike a SAST, it **executes a proof-of-concept exploit**
to decide whether a finding is real. That verdict is the thing worth having; the
rest of the workflow (branching, PRs, summarising) is yours.

```
cm find    …  scan and report candidates      (--deep: ~2–3 min / 13 files)
cm verify  …  write and RUN an exploit        (~10–16 min in Cloud Shell)  ★ the value ★
cm fix     …  patch, build, test, re-exploit  (~3 min)
```

## Read this before running anything

### ★ `cm` DELETES UNCOMMITTED WORK ★

`find`, `verify`, and `fix` each begin by resetting the workspace:

```
git checkout HEAD -- . && git clean -fd
```

`git clean -fd` removes **untracked files**, not just edits. This has destroyed
work three times in practice, including output that was redirected into the repo
by the very command that was running.

So, without exception:

1. **Commit or stash everything before calling `cm`.** Check `git status --short`
   first and stop if it is dirty.
2. **Never redirect `cm` output into the repository.** Write to `/tmp`.

### It cannot answer prompts — you have no TTY

- `-y` covers per-command and per-write confirmations.
- **`-y` does NOT cover the responsibility warning.** Only `--bypass-warning` does.
  It appears on every session that runs commands (`verify`, `fix`) and is never
  remembered.
- Without both, non-interactive runs die with
  `responsibility warning: warning not acknowledged`.

**Always pass `-y --bypass-warning`.** Tell the user you are doing so: it
auto-accepts "the agent may modify files and execute commands on your system."

`cm build` is the exception: it prompts and **ignores `-y`** (0.7.0, measured:
`failed to read confirmation`). Pass `--force` to it.

### `cm verify` can approach the Bash tool timeout

Measured at ~10–16 minutes in Cloud Shell, 2–4 on a fast workstation (gemini-3.8-flash, cm 0.11.0). The Bash tool caps at 10 minutes,
so a run can hit the wall. **Run `verify` and `fix` with `run_in_background: true`**,
then poll.

### Findings do not always record a usable path

`verify` and `fix` resolve the finding's `FilePath` relative to the current
directory, and that path is recorded inconsistently — sometimes absolute,
sometimes **just the basename**. Measured: 2 of 8 scan sessions stored bare
basenames, from the same command and the same CLI version. The format is
consistent within a session, so an affected scan fails for every finding in it.

```
Error: reading source file attachments.py: open attachments.py: no such file
Try running 'cm verify' from the project root where the scan was originally performed
```

That advice is wrong — the project root is exactly where it fails.

**Run `verify` and `fix` from the directory that contains the file**, which works
for both formats. Read `FilePath` out of `cm report --format json` and `cd` there
first rather than assuming the repository root.

### Pin the model

```
--model gemini-3.8-flash
```

Measured on cm 0.11.0 (its default model is `gemini-3.8-flash`; `gemini-3.8-flash-cyber`
is also offered and was not evaluated here):

| Model | Result |
|---|---|
| **`gemini-3.8-flash`** (cm 0.11.0 default) | `--deep`: the 3 core findings at 100%, plus DNS rebinding in an HTTP helper; ~3 min |
| `gemini-3.7-flash` | `--deep`: same core findings, but also flags CSV formula injection in an export module; ~1 min |
| `gemini-3.6-flash` | 3 findings at 100% confidence, ~3 min (quick scan, measured on 0.5.0) |
| `gemini-3.5-flash` | 3 findings at 100% confidence, ~3 min (quick scan, measured on 0.5.0) |

### Pick the scan mode

| Mode | Use it for |
|---|---|
| `cm find <dir>` (quick) | Fast interactive discovery. One agent session; lowest cost |
| `cm find <dir> --deep` | A real security review. Every source file, 8 parallel workers (`--deep-workers` 1–16), candidates corroborated before they are reported |
| `cm find . --diff=origin/main` | CI on a pull request: changed hunks plus 1-hop callers, `--fail-on`, native SARIF |

`--deep` and `--diff` are mutually exclusive. For "security review this repo", use `--deep`.

### Pre-GA

Access is per-project allowlist, and the terms restrict use to limited testing
and evaluation. **Do not wire this into a merge gate or a production pipeline.**
Ad-hoc, human-reviewed runs are the intended shape.

## Preflight

Stop and report rather than working around a failure here.

```bash
command -v cm || echo "cm not installed"
git rev-parse --git-dir >/dev/null 2>&1 || echo "not a git repository"
git status --short                      # must be empty
gcloud config get-value project
cm init --verify                        # 7 passed / 1 warning is the healthy state
```

`Access to the CodeMender preview release must be coordinated` or
`Unsupported agent interaction: codemender-preview` means the project is not
allowlisted. **That cannot be fixed from here** — say so and stop.

## Workflow

### 1. Scan

Keep to 10–50 files per scan. Point at a directory, not the repo root.

```bash
cm find src/ --deep --compact -y --bypass-warning --model gemini-3.8-flash
cm report --status OPEN --format json > /tmp/cm-findings.json
```

Note that the scan target does not bound the results — the agent explores all of
`project_paths`, so findings may appear in files you did not name.

### 2. Decide what is worth verifying

Verification costs ~5–8 minutes and ~55–70k tokens each. Do not verify everything.

Read `/tmp/cm-findings.json` and prioritise by whether exploitability is actually
in doubt. Say what you are skipping and why.

Add domain knowledge with `-c` when the codebase has invariants the agent cannot
infer:

```bash
cm verify <id> -c "Multi-tenant app; every query must scope by tenant_id."
```

### 3. Verify — this is the point

```bash
cm verify <finding-id> -y --bypass-warning --model gemini-3.8-flash
```

Run in the background. Then:

```bash
cm report --artifacts
```

Artifacts land in `~/.codemender/artifacts/<session>/`:

| File | Contents |
|---|---|
| `PLAN.md` | how it intends to prove the bug |
| `exploit.sh` | the exploit it actually ran |
| `REPORT.md` | analysis and fix recommendation |
| `info.yaml` | **the verdict** — read this one |
| `LOG.md` | the full agent transcript |

Filenames are **uppercase**. `info.yaml` carries the verdict even when the CLI
prints "no results were returned".

A dismissed finding is a result, not a failure. `status: invalid` with
`confidence: certain` means it tried to exploit it and could not. Report that as
confidently as a confirmed one — it is the feature.

### 4. Fix

```bash
cm fix <finding-id> -y --bypass-warning --model gemini-3.8-flash
cm vcs diff
```

On cm 0.5.0–0.7.0 `cm fix` writes the patch but does **not** stage it, and drops an
enforced-ignore `.gitignore` in the scanned dir — stage the real change yourself
and don't commit that `.gitignore`. It runs `build.command` afterwards, so the
quality of the repo's tests determines the quality of the verification.

Steer it toward the codebase's own conventions:

```bash
cm fix <id> --no-cache -c "Use the existing helper in common/http_client.py."
```

`--no-cache` matters — without it a repeat call returns the cached patch and
ignores the new context.

To undo: `cm vcs reset --force` (this command takes `--force`, not `-y`).

### 5. Review, then PR

**Read the diff yourself before proposing it.** Check that it is minimal, matches
surrounding style, and does not neuter a feature to silence the finding — the
classic failure is turning a broken authorization check into a blanket denial.
Run the tests.

Then branch, commit, and open a PR whose body carries the evidence:

- what the defect is, in one sentence
- **that the exploit ran and what it retrieved** — this is what makes the PR
  persuasive; quote from `exploit.sh` / `REPORT.md`
- what the patch changes and why it is minimal
- which tests prove the feature still works

**Never auto-merge, and never present the patch as pre-approved.** `-y` skips
confirmations; it does not skip review. Say plainly that a human must read it.

## Reporting to the user

Give the verdict, not the log. For each finding: is it real, how do we know, what
does the fix change, what did it cost. Distinguish "the tool says so" from "the
exploit ran and returned another tenant's data" — the second is the reason to use
this tool at all.

Results vary between runs; it is an LLM agent. If a finding does not reproduce,
say so rather than presenting one run as definitive.
